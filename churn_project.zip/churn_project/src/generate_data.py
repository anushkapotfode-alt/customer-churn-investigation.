"""Simulate a subscription-business customer table, then optionally corrupt it the way
real exports get corrupted (duplicates, mixed labels, typos, impossible values).

No real customer data is used anywhere in this project.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as C


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def _logit_core(d: dict, rng: np.random.Generator, drift: dict | None = None) -> np.ndarray:
    """Ground-truth churn mechanism (hidden from the analyst, used only to simulate).
    `drift` can change the mechanism itself (concept drift), not just the customer mix."""
    drift = drift or {}
    mtm = d["contract"] == "Month-to-month"
    one = d["contract"] == "One year"
    two = d["contract"] == "Two year"
    plan_eff = np.select([d["plan"] == "Premium", d["plan"] == "Basic"], [-0.3, 0.2], 0.0)
    return (
        drift.get("mtm_effect", 1.0) * mtm - 0.2 * one - 1.0 * two
        - 0.035 * d["tenure_months"]
        + 0.28 * d["support_tickets_90d"]
        - 0.07 * (d["logins_30d"] - 14)
        + 0.35 * d["late_payments_6m"]
        - 0.5 * d["autopay"]
        + drift.get("price_effect", 0.6) * d["price_increase_recent"]
        - 0.4 * d["discount_flag"]
        - 0.3 * d["referred"]
        + 0.25 * (d["payment_method"] == "Wallet")
        + 0.4 * (d["age"] < 25)
        + plan_eff
        + rng.normal(0, 0.5, len(d["age"]))
    )


def _draw_features(n: int, rng: np.random.Generator, drift: dict) -> dict:
    contract = rng.choice(C.CONTRACTS, n, p=[0.55, 0.25, 0.20])
    plan = rng.choice(C.PLANS, n, p=[0.40, 0.38, 0.22])
    mean_t = np.select([contract == "Month-to-month", contract == "One year"], [14, 28], 40)
    tenure = np.clip(np.round(rng.exponential(mean_t)), 1, 72).astype(int)
    base = np.array([{"Basic": 20.0, "Standard": 45.0, "Premium": 80.0}[p] for p in plan])
    monthly = np.round(base + rng.normal(0, 5, n) + rng.choice([0, 5, 10], n, p=[0.6, 0.25, 0.15]), 2)
    payment = rng.choice(C.PAYMENTS, n, p=[0.35, 0.30, 0.20, 0.15])
    autopay = (rng.random(n) < np.where(np.isin(payment, ["Card", "Bank Transfer"]), 0.7, 0.35)).astype(int)
    engagement = rng.normal(drift.get("engagement_shift", 0.0), 1, n)
    logins = np.clip(np.round(14 + 6 * engagement + rng.normal(0, 2, n)), 0, None).astype(int)
    session = np.round(np.clip(12 + 4 * engagement + rng.normal(0, 2, n), 1, None), 1)
    unhappy = rng.normal(0, 1, n)
    lam = np.clip(1.0 + 0.7 * unhappy - 0.2 * engagement + drift.get("ticket_shift", 0.0), 0.05, None)
    tickets = rng.poisson(lam)
    late = np.clip(rng.poisson(0.35 + 0.5 * (payment == "Wallet") + 0.3 * (autopay == 0)), 0, 6)
    price_inc = (rng.random(n) < drift.get("price_increase_rate", 0.20)).astype(int)
    discount = (rng.random(n) < 0.25).astype(int)
    referred = (rng.random(n) < 0.15).astype(int)
    age = np.clip(np.round(rng.normal(38, 12, n)), 18, 80).astype(int)
    region = rng.choice(C.REGIONS, n, p=[0.30, 0.25, 0.25, 0.20])
    total = np.round(monthly * tenure * rng.uniform(0.95, 1.05, n), 2)
    return dict(
        plan=plan, contract=contract, payment_method=payment, region=region, age=age,
        tenure_months=tenure, monthly_charges=monthly, total_charges=total,
        support_tickets_90d=tickets, logins_30d=logins, avg_session_min=session,
        late_payments_6m=late, autopay=autopay, price_increase_recent=price_inc,
        discount_flag=discount, referred=referred,
    )


def calibrate_intercept(target=C.TARGET_CHURN_RATE, n=60000, seed=123) -> float:
    """Bisection so the base simulator yields roughly the target churn rate."""
    rng = np.random.default_rng(seed)
    d = _draw_features(n, rng, {})
    core = _logit_core(d, rng)
    lo, hi = -8.0, 4.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if _sigmoid(core + mid).mean() > target:
            hi = mid
        else:
            lo = mid
    return round((lo + hi) / 2, 4)


def simulate(n: int = C.N_CUSTOMERS, seed: int = C.SEED, drift: dict | None = None,
             intercept: float | None = None) -> pd.DataFrame:
    """Return the *true* (clean) customer table."""
    drift = drift or {}
    rng = np.random.default_rng(seed)
    d = _draw_features(n, rng, drift)
    if intercept is None:
        intercept = C.SIM_INTERCEPT if C.SIM_INTERCEPT is not None else calibrate_intercept()
    p = _sigmoid(_logit_core(d, rng, drift) + intercept)
    churn = (rng.random(n) < p).astype(int)
    df = pd.DataFrame(d)
    df.insert(0, C.ID_COL, [f"C{seed % 100}{i:06d}" for i in range(1, n + 1)])
    df[C.TARGET] = churn
    return df


def make_raw(df: pd.DataFrame, seed: int = C.SEED) -> tuple[pd.DataFrame, dict]:
    """Corrupt a clean table like a messy real-world export. Returns (raw, ground-truth counts)."""
    rng = np.random.default_rng(seed + 1000)
    raw = df.copy()
    n = len(raw)
    truth: dict = {}

    def pick(frac):
        return rng.random(n) < frac

    # 1. category typos / casing / whitespace
    variants = {
        "plan": [str.lower, str.upper, lambda s: s + " ", lambda s: " " + s],
        "contract": [str.lower, str.upper, lambda s: s.replace("-", " "), lambda s: s + " "],
        "payment_method": [str.lower, str.upper, lambda s: " " + s],
        "region": [str.lower, str.upper, lambda s: s + " "],
    }
    truth["category_variants"] = 0
    for col, fns in variants.items():
        mask = pick(0.06)
        vals = raw[col].astype(object).copy()
        for i in np.where(mask)[0]:
            vals.iat[i] = fns[rng.integers(len(fns))](vals.iat[i])
        raw[col] = vals
        truth["category_variants"] += int((raw[col] != df[col]).sum())

    # 2. missing values
    truth["missing_injected"] = {}
    for col, frac in {"monthly_charges": 0.015, "age": 0.03, "logins_30d": 0.02,
                      "avg_session_min": 0.02, "support_tickets_90d": 0.01}.items():
        m = pick(frac)
        raw[col] = raw[col].astype(float)
        raw.loc[m, col] = np.nan
        truth["missing_injected"][col] = int(m.sum())

    # 3. impossible values
    truth["invalid_injected"] = {}
    m = pick(0.004)
    raw["age"] = raw["age"].astype(float)
    raw.loc[m, "age"] = rng.choice([0, -1, 150, 999], m.sum())
    truth["invalid_injected"]["age"] = int(m.sum())
    m = pick(0.005)
    raw["tenure_months"] = raw["tenure_months"].astype(float)
    raw.loc[m, "tenure_months"] = -rng.integers(1, 12, m.sum())
    truth["invalid_injected"]["tenure_months"] = int(m.sum())
    m = pick(0.003) & raw["monthly_charges"].notna()
    raw.loc[m, "monthly_charges"] = raw.loc[m, "monthly_charges"] * 100
    truth["invalid_injected"]["monthly_charges"] = int(m.sum())
    m = pick(0.002) & raw["logins_30d"].notna()
    raw.loc[m, "logins_30d"] = -5
    truth["invalid_injected"]["logins_30d"] = int(m.sum())

    # 4. total_charges exported as text, with blanks / "N/A"
    tc = raw["total_charges"].astype(object).copy()
    m_blank = pick(0.01)
    m_na = pick(0.003) & ~m_blank
    tc[m_blank] = " "
    tc[m_na] = "N/A"
    raw["total_charges"] = tc
    truth["total_charges_text_blank"] = int(m_blank.sum() + m_na.sum())

    # 5. churn label in mixed formats (+ a few missing)
    lab = raw[C.TARGET].astype(object).copy()
    fmt = rng.integers(0, 4, n)
    for i in range(n):
        v = int(df[C.TARGET].iat[i])
        lab.iat[i] = [("Yes", "No"), ("yes", "no"), (1, 0), ("Y", "N")][fmt[i]][0 if v == 1 else 1]
    m_lab = pick(0.002)
    lab[m_lab] = np.nan
    raw[C.TARGET] = lab
    truth["label_missing"] = int(m_lab.sum())

    # 6. duplicates: exact copies + conflicting duplicate ids
    n_exact = int(0.02 * n)
    exact = raw.sample(n_exact, random_state=seed)
    n_conf = int(0.003 * n)
    conf = raw.sample(n_conf, random_state=seed + 1).copy()
    conf["monthly_charges"] = conf["monthly_charges"] * 1.1
    raw = pd.concat([raw, exact, conf], ignore_index=True)
    raw = raw.sample(frac=1, random_state=seed).reset_index(drop=True)
    truth["exact_duplicates"] = n_exact
    truth["conflicting_id_duplicates"] = n_conf
    truth["rows_raw"] = len(raw)
    truth["rows_true"] = n
    return raw, truth


def main():
    import json
    C.DATA_RAW.mkdir(parents=True, exist_ok=True)
    C.REPORTS.mkdir(parents=True, exist_ok=True)
    C.SIM_INTERCEPT = calibrate_intercept()
    clean_truth = simulate()
    raw, truth = make_raw(clean_truth)
    raw.to_csv(C.DATA_RAW / "churn_raw.csv", index=False)
    clean_truth.to_csv(C.DATA_RAW / "_ground_truth_clean.csv", index=False)
    truth["simulator_intercept"] = C.SIM_INTERCEPT
    truth["true_churn_rate"] = round(float(clean_truth[C.TARGET].mean()), 4)
    (C.REPORTS / "simulation_truth.json").write_text(json.dumps(truth, indent=2))
    print(f"raw rows={len(raw)}, true churn rate={truth['true_churn_rate']}")


if __name__ == "__main__":
    main()
