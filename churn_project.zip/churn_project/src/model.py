"""Churn prediction: baselines vs models, leakage-safe preprocessing, honest evaluation.

Imputation, scaling and encoding all live inside the sklearn Pipeline, so they are fitted on
training folds only. The test set is touched once, after the model choice is made.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from . import config as C

CAT = list(C.CATEGORICAL)
NUM = C.NUMERIC
BIN = C.BINARY
assert C.TARGET not in C.FEATURES and C.ID_COL not in C.FEATURES   # guard against leakage


def build_preprocessor() -> ColumnTransformer:
    return ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median", add_indicator=True)),
                          ("sc", StandardScaler())]), NUM),
        ("bin", SimpleImputer(strategy="most_frequent"), BIN),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="constant", fill_value="Unknown")),
                          ("oh", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), CAT),
    ])


def build_model(kind: str, seed: int = C.SEED) -> Pipeline:
    if kind == "logistic":
        clf = LogisticRegression(max_iter=2000, C=1.0)
    elif kind == "gradient_boosting":
        clf = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=250,
                                             l2_regularization=1.0, random_state=seed)
    else:
        raise ValueError(kind)
    return Pipeline([("prep", build_preprocessor()), ("clf", clf)])


# ---------------------------------------------------------------- baselines
def rule_score(X: pd.DataFrame, seed: int = C.SEED) -> np.ndarray:
    """Expert-style heuristic a retention team could run in a spreadsheet: count of risk flags.
    Ties are broken randomly (seeded) so ranking metrics are well defined."""
    flags = (
        (X["contract"] == "Month-to-month").astype(int)
        + (X["tenure_months"] <= 12).astype(int)
        + (X["support_tickets_90d"] >= 3).astype(int)
        + (X["late_payments_6m"] >= 2).astype(int)
        + (X["autopay"] == 0).astype(int)
        + (X["price_increase_recent"] == 1).astype(int)
    ).to_numpy(dtype=float)
    return flags + np.random.default_rng(seed).uniform(0, 0.01, len(X))


# ---------------------------------------------------------------- metrics
def topk_stats(y: np.ndarray, score: np.ndarray, frac: float) -> dict:
    n_top = int(np.ceil(frac * len(y)))
    idx = np.argsort(-score, kind="stable")[:n_top]
    captured = int(y[idx].sum())
    base = y.mean()
    return {"contacted": n_top, "churners_captured": captured, "precision": captured / n_top,
            "recall": captured / y.sum(), "lift": (captured / n_top) / base}


def evaluate(y, score, frac=C.CAMPAIGN_BUDGET_FRACTION) -> dict:
    y = np.asarray(y)
    out = {"roc_auc": float(roc_auc_score(y, score)), "pr_auc": float(average_precision_score(y, score))}
    out.update({f"top{int(frac*100)}_{k}": v for k, v in topk_stats(y, score, frac).items()})
    return out


def bootstrap_ci(y, score, fn, n_boot=500, seed=C.SEED):
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if y[idx].min() == y[idx].max():
            continue
        vals.append(fn(y[idx], np.asarray(score)[idx]))
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def paired_capture_diff_ci(y, s_model, s_base, frac=C.CAMPAIGN_BUDGET_FRACTION, n_boot=500, seed=C.SEED):
    """95% CI for (model - baseline) share of churners captured in the top `frac`."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    s_model, s_base = np.asarray(s_model), np.asarray(s_base)
    diffs = []
    for _ in range(n_boot):
        i = rng.integers(0, len(y), len(y))
        diffs.append(topk_stats(y[i], s_model[i], frac)["recall"] - topk_stats(y[i], s_base[i], frac)["recall"])
    return [float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))]


def business_case(y, score, monthly_charges, frac=C.CAMPAIGN_BUDGET_FRACTION) -> dict:
    """Net value of a retention campaign under the (illustrative) assumptions in config."""
    y, monthly_charges = np.asarray(y), np.asarray(monthly_charges)
    n_top = int(np.ceil(frac * len(y)))
    idx = np.argsort(-np.asarray(score), kind="stable")[:n_top]
    churners = y[idx] == 1
    saved = churners.sum() * C.SAVE_RATE
    value = (monthly_charges[idx][churners] * C.SAVE_RATE).sum() * C.GROSS_MARGIN * C.VALUE_MONTHS
    cost = n_top * C.OFFER_COST_PER_CUSTOMER
    return {"contacted": int(n_top), "expected_customers_saved": float(saved),
            "expected_margin_retained": float(value), "campaign_cost": float(cost),
            "net_value": float(value - cost)}


# ---------------------------------------------------------------- calibration
def calibration_table(y, p, bins=10) -> pd.DataFrame:
    df = pd.DataFrame({"y": np.asarray(y), "p": np.asarray(p)})
    df["bin"] = pd.qcut(df["p"].rank(method="first"), bins, labels=False)
    t = df.groupby("bin").agg(n=("y", "size"), mean_predicted=("p", "mean"), observed_rate=("y", "mean")).reset_index()
    return t


# ---------------------------------------------------------------- main training routine
def split(df: pd.DataFrame, seed: int = C.SEED):
    X, y = df[C.FEATURES], df[C.TARGET].astype(int)
    return train_test_split(X, y, test_size=0.2, stratify=y, random_state=seed)


def train_and_evaluate(df: pd.DataFrame, seed: int = C.SEED, save: bool = True) -> dict:
    X_tr, X_te, y_tr, y_te = split(df, seed)
    cv = StratifiedKFold(5, shuffle=True, random_state=seed)

    # 1. model selection with cross-validation on TRAIN only
    cv_res = {}
    for kind in ["logistic", "gradient_boosting"]:
        r = cross_validate(build_model(kind, seed), X_tr, y_tr, cv=cv,
                           scoring={"roc_auc": "roc_auc", "pr_auc": "average_precision"})
        cv_res[kind] = {"roc_auc_mean": float(r["test_roc_auc"].mean()), "roc_auc_std": float(r["test_roc_auc"].std()),
                        "pr_auc_mean": float(r["test_pr_auc"].mean())}
    # decision rule (fixed before looking at test data): prefer the interpretable model unless the
    # complex one is better by more than 0.01 CV AUC
    chosen = "gradient_boosting" if (cv_res["gradient_boosting"]["roc_auc_mean"]
                                     - cv_res["logistic"]["roc_auc_mean"] > 0.01) else "logistic"

    # 2. fit final model on train, evaluate ONCE on held-out test
    model = build_model(chosen, seed).fit(X_tr, y_tr)
    p_te = model.predict_proba(X_te)[:, 1]
    s_rule = rule_score(X_te, seed)
    rng = np.random.default_rng(seed)
    s_rand = rng.random(len(y_te))

    results = {
        "random": evaluate(y_te, s_rand),
        "rule_baseline": evaluate(y_te, s_rule),
        chosen: evaluate(y_te, p_te),
    }
    # also report the non-chosen model on test for transparency (not used for selection)
    other = "logistic" if chosen == "gradient_boosting" else "gradient_boosting"
    other_m = build_model(other, seed).fit(X_tr, y_tr)
    results[other] = evaluate(y_te, other_m.predict_proba(X_te)[:, 1])

    ci = {
        "model_roc_auc_ci95": bootstrap_ci(y_te, p_te, roc_auc_score),
        "rule_roc_auc_ci95": bootstrap_ci(y_te, s_rule, roc_auc_score),
        "recall_gain_vs_rule_top20_ci95": paired_capture_diff_ci(y_te, p_te, s_rule),
    }
    calib = calibration_table(y_te, p_te)
    brier = float(brier_score_loss(y_te, p_te))
    brier_base = float(brier_score_loss(y_te, np.full(len(y_te), y_tr.mean())))

    # 3. explainability
    pi = permutation_importance(model, X_te, y_te, scoring="roc_auc", n_repeats=10, random_state=seed)
    imp = pd.DataFrame({"feature": X_te.columns, "auc_drop": pi.importances_mean, "std": pi.importances_std})
    imp = imp.sort_values("auc_drop", ascending=False).reset_index(drop=True)
    odds = None
    if chosen == "logistic":
        names = model.named_steps["prep"].get_feature_names_out()
        coefs = model.named_steps["clf"].coef_[0]
        odds = pd.DataFrame({"feature": names, "coef": coefs, "odds_ratio": np.exp(coefs)})
        odds = odds.reindex(odds["coef"].abs().sort_values(ascending=False).index).reset_index(drop=True)

    biz = {
        "random": business_case(y_te, s_rand, X_te["monthly_charges"].fillna(X_tr["monthly_charges"].median())),
        "rule_baseline": business_case(y_te, s_rule, X_te["monthly_charges"].fillna(X_tr["monthly_charges"].median())),
        "model": business_case(y_te, p_te, X_te["monthly_charges"].fillna(X_tr["monthly_charges"].median())),
    }

    scored = X_te.copy()
    scored["customer_id"] = df.loc[X_te.index, C.ID_COL].values
    scored["churned"] = y_te.values
    scored["churn_probability"] = p_te
    scored["rule_score"] = s_rule

    # risk bands from training-score quantiles, saved with the model for consistent scoring later
    p_tr = model.predict_proba(X_tr)[:, 1]
    bands = {"high_threshold": float(np.quantile(p_tr, 0.90)), "medium_threshold": float(np.quantile(p_tr, 0.70))}

    summary = {
        "n_train": int(len(X_tr)), "n_test": int(len(X_te)), "test_churn_rate": float(y_te.mean()),
        "cv": cv_res, "chosen_model": chosen, "selection_rule": "logistic unless GB CV ROC-AUC higher by > 0.01",
        "test": results, "confidence_intervals": ci, "brier_score": brier, "brier_baseline_prevalence": brier_base,
        "calibration_mean_abs_gap": float((calib["mean_predicted"] - calib["observed_rate"]).abs().mean()),
        "business_case_top20": biz, "risk_bands": bands,
        "assumptions": {"campaign_budget_fraction": C.CAMPAIGN_BUDGET_FRACTION, "offer_cost": C.OFFER_COST_PER_CUSTOMER,
                        "save_rate": C.SAVE_RATE, "gross_margin": C.GROSS_MARGIN, "value_months": C.VALUE_MONTHS},
    }
    artefacts = {"model": model, "other_model": other_m, "summary": summary, "calibration": calib,
                 "importance": imp, "odds": odds, "scored_test": scored,
                 "split": (X_tr, X_te, y_tr, y_te)}
    if save:
        save_artefacts(artefacts, df)
    return artefacts


def data_hash(df: pd.DataFrame) -> str:
    return hashlib.sha256(pd.util.hash_pandas_object(df, index=False).values.tobytes()).hexdigest()[:16]


def save_artefacts(a: dict, df: pd.DataFrame):
    C.MODELS.mkdir(parents=True, exist_ok=True)
    C.REPORTS.mkdir(parents=True, exist_ok=True)
    meta = {"trained_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "chosen_model": a["summary"]["chosen_model"], "features": C.FEATURES,
            "risk_bands": a["summary"]["risk_bands"], "training_data_hash": data_hash(df),
            "reference_rows": int(len(df))}
    joblib.dump({"pipeline": a["model"], "meta": meta}, C.MODELS / "churn_model.joblib")
    (C.REPORTS / "model_metrics.json").write_text(json.dumps(a["summary"], indent=2))
    a["calibration"].to_csv(C.REPORTS / "calibration_table.csv", index=False)
    a["importance"].to_csv(C.REPORTS / "permutation_importance.csv", index=False)
    if a["odds"] is not None:
        a["odds"].to_csv(C.REPORTS / "logistic_odds_ratios.csv", index=False)
    a["scored_test"].to_csv(C.REPORTS / "test_set_risk_scores.csv", index=False)


def plot_model(a: dict):
    sns.set_theme(style="whitegrid")
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False})
    s = a["summary"]
    chosen = s["chosen_model"]
    sc = a["scored_test"]
    y = sc["churned"].values

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    # capture curve
    fr = np.linspace(0.01, 1, 100)
    for name, col, color in [("Model", "churn_probability", "#2F6DB5"), ("Rule baseline", "rule_score", "#8A8F98")]:
        axes[0].plot(fr * 100, [topk_stats(y, sc[col].values, f)["recall"] * 100 for f in fr], label=name, color=color, lw=2)
    axes[0].plot(fr * 100, fr * 100, "--", color="#E4572E", label="Random")
    axes[0].axvline(20, color="k", lw=0.6, ls=":")
    axes[0].set_xlabel("% of customers contacted (highest risk first)")
    axes[0].set_ylabel("% of churners reached")
    axes[0].set_title("Cumulative capture of churners (test set)")
    axes[0].legend(frameon=False)
    # calibration
    cal = a["calibration"]
    axes[1].plot([0, 0.8], [0, 0.8], "--", color="#8A8F98")
    axes[1].plot(cal["mean_predicted"], cal["observed_rate"], "o-", color="#2F6DB5")
    axes[1].set_xlabel("Mean predicted probability (decile)")
    axes[1].set_ylabel("Observed churn rate")
    axes[1].set_title("Calibration by decile")
    # importance
    imp = a["importance"].head(10).iloc[::-1]
    axes[2].barh(imp["feature"], imp["auc_drop"], xerr=imp["std"], color="#2F6DB5")
    axes[2].set_xlabel("Drop in ROC-AUC when shuffled")
    axes[2].set_title("Permutation importance (top 10)")
    fig.tight_layout()
    fig.savefig(C.FIG / "10_model_evaluation.png", dpi=130)
    plt.close(fig)

    if a["odds"] is not None:
        o = a["odds"].head(14).iloc[::-1]
        fig, ax = plt.subplots(figsize=(7.5, 5))
        ax.barh(o["feature"].str.replace("cat__", "").str.replace("num__", "").str.replace("bin__", ""),
                o["odds_ratio"] - 1, color=np.where(o["odds_ratio"] > 1, "#E4572E", "#2F6DB5"))
        ax.axvline(0, color="k", lw=0.8)
        ax.set_xlabel("Change in odds of churn per unit (std. units for numeric): odds ratio - 1")
        ax.set_title("Logistic regression: strongest effects")
        fig.tight_layout()
        fig.savefig(C.FIG / "11_logistic_effects.png", dpi=130)
        plt.close(fig)


def main():
    df = pd.read_csv(C.DATA_PROCESSED / "churn_clean.csv")
    a = train_and_evaluate(df)
    plot_model(a)
    s = a["summary"]
    print("chosen:", s["chosen_model"])
    print(json.dumps({"cv": s["cv"], "test": s["test"], "ci": s["confidence_intervals"],
                      "biz": s["business_case_top20"], "brier": s["brier_score"],
                      "brier_base": s["brier_baseline_prevalence"], "calib_gap": s["calibration_mean_abs_gap"]}, indent=1))
    print(a["importance"].head(8).to_string(index=False))


if __name__ == "__main__":
    main()
