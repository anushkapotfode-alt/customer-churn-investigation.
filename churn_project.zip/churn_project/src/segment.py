"""Customer segmentation with KMeans on behavioural/commercial features (never on the churn label)."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler

from . import config as C

SEG_FEATURES = ["tenure_months", "monthly_charges", "logins_30d", "avg_session_min",
                "support_tickets_90d", "late_payments_6m"]
PRETTY = {"tenure_months": "tenure", "monthly_charges": "spend", "logins_30d": "logins",
          "avg_session_min": "session length", "support_tickets_90d": "tickets", "late_payments_6m": "late payments"}


def _prep(df: pd.DataFrame):
    imp = SimpleImputer(strategy="median")
    sc = StandardScaler()
    X = sc.fit_transform(imp.fit_transform(df[SEG_FEATURES]))
    return X, imp, sc


def choose_k(X, k_range=range(3, 7), seed=C.SEED) -> tuple[int, dict]:
    scores = {}
    for k in k_range:
        labels = KMeans(n_clusters=k, n_init=10, random_state=seed).fit_predict(X)
        scores[k] = round(float(silhouette_score(X, labels, sample_size=3000, random_state=seed)), 4)
    return max(scores, key=scores.get), scores


def describe_segment(z: pd.Series) -> str:
    """Auto-name a segment from its two most distinctive features (z-scores vs the whole base)."""
    top = z.reindex(z.abs().sort_values(ascending=False).index)[:2]
    parts = [f"{'high' if v > 0 else 'low'} {PRETTY[f]}" for f, v in top.items()]
    return " + ".join(parts)


def fit_segments(df: pd.DataFrame, seed: int = C.SEED):
    X, imp, sc = _prep(df)
    k, sil = choose_k(X, seed=seed)
    km = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(X)
    labels = km.labels_

    # stability: refit on 80% subsamples with different seeds, compare with full-data labels
    rng = np.random.default_rng(seed)
    aris = []
    for s in range(5):
        idx = rng.choice(len(X), int(0.8 * len(X)), replace=False)
        km_s = KMeans(n_clusters=k, n_init=10, random_state=seed + 100 + s).fit(X[idx])
        aris.append(adjusted_rand_score(labels, km_s.predict(X)))

    d = df.copy()
    d["segment_id"] = labels
    z = pd.DataFrame(sc.transform(imp.transform(d[SEG_FEATURES])), columns=SEG_FEATURES)
    z["segment_id"] = labels
    zc = z.groupby("segment_id").mean()
    prof = d.groupby("segment_id").agg(
        customers=("customer_id", "size"), churn_rate=(C.TARGET, "mean"),
        avg_tenure=("tenure_months", "mean"), avg_monthly_charges=("monthly_charges", "mean"),
        avg_logins=("logins_30d", "mean"), avg_tickets=("support_tickets_90d", "mean"),
        avg_late=("late_payments_6m", "mean"), month_to_month_share=("contract", lambda s: (s == "Month-to-month").mean()),
    )
    lost = d[d[C.TARGET] == 1].groupby("segment_id")["monthly_charges"].sum()
    prof["monthly_revenue_lost"] = lost.reindex(prof.index).fillna(0)
    prof["share_of_customers"] = prof["customers"] / len(d)
    prof["share_of_revenue_lost"] = prof["monthly_revenue_lost"] / prof["monthly_revenue_lost"].sum()
    prof["description"] = [describe_segment(zc.loc[i]) for i in prof.index]
    prof = prof.sort_values("churn_rate", ascending=False)
    prof["segment_name"] = [f"S{i+1}" for i in range(len(prof))]   # S1 = highest churn
    rename = dict(zip(prof.index, prof["segment_name"]))
    d["segment"] = d["segment_id"].map(rename)
    meta = {"k": int(k), "silhouette_by_k": sil, "stability_ARI_mean": round(float(np.mean(aris)), 4),
            "stability_ARI_min": round(float(np.min(aris)), 4)}
    return d, prof.reset_index(drop=True), zc.rename(index=rename), meta, (X, rename)


def plot_segments(d: pd.DataFrame, prof: pd.DataFrame, zc: pd.DataFrame, X, rename):
    sns.set_theme(style="whitegrid")
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False})
    C.FIG.mkdir(parents=True, exist_ok=True)
    pcs = PCA(2, random_state=C.SEED).fit_transform(X)
    segs = d["segment"].values
    order = sorted(set(segs))
    palette = dict(zip(order, sns.color_palette("tab10", len(order))))

    fig, axes = plt.subplots(1, 3, figsize=(16, 4.6), gridspec_kw={"width_ratios": [1.1, 1, 1]})
    for s in order:
        m = segs == s
        axes[0].scatter(pcs[m, 0], pcs[m, 1], s=6, alpha=0.5, color=palette[s], label=s)
    axes[0].set_title("Segments in PCA space")
    axes[0].legend(markerscale=3, frameon=False)
    axes[0].set_xlabel("PC1")
    axes[0].set_ylabel("PC2")

    p = prof.set_index("segment_name").reindex(order)
    axes[1].bar(order, p["churn_rate"] * 100, color=[palette[s] for s in order])
    axes[1].axhline(d[C.TARGET].mean() * 100, color="#E4572E", ls="--", lw=1)
    for i, (r, n) in enumerate(zip(p["churn_rate"], p["customers"])):
        axes[1].text(i, r * 100 + 0.6, f"{r*100:.0f}%\nn={n}", ha="center", fontsize=8)
    axes[1].set_title("Churn rate by segment")
    axes[1].set_ylabel("%")

    sns.heatmap(zc.reindex(order).rename(columns=PRETTY), annot=True, fmt=".2f", cmap="coolwarm", center=0,
                ax=axes[2], cbar_kws={"label": "z-score vs all customers"}, annot_kws={"size": 8})
    axes[2].set_title("What defines each segment")
    axes[2].set_ylabel("")
    fig.tight_layout()
    fig.savefig(C.FIG / "09_segments.png", dpi=130)
    plt.close(fig)


def main():
    import json
    df = pd.read_csv(C.DATA_PROCESSED / "churn_clean.csv")
    d, prof, zc, meta, (X, rename) = fit_segments(df)
    plot_segments(d, prof, zc, X, rename)
    prof.to_csv(C.REPORTS / "segment_profiles.csv", index=False)
    d[["customer_id", "segment"]].to_csv(C.DATA_PROCESSED / "customer_segments.csv", index=False)
    (C.REPORTS / "segmentation_meta.json").write_text(json.dumps(meta, indent=2))
    pd.set_option("display.width", 200)
    print(meta)
    print(prof[["segment_name", "customers", "churn_rate", "avg_tenure", "avg_monthly_charges", "avg_logins",
                "avg_tickets", "avg_late", "month_to_month_share", "share_of_revenue_lost", "description"]].round(2).to_string(index=False))


if __name__ == "__main__":
    main()
