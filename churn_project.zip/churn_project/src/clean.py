"""Cleaning + data-quality checks. Every change is counted and returned in a report.

Design rules:
  * Never silently keep an impossible value: it becomes missing (NaN) and is counted.
  * Only deterministic cross-field repairs happen here (e.g. total = monthly x tenure).
    Statistical imputation happens inside the model pipeline, fitted on training data only,
    so no information leaks from the test set.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from . import config as C


class SchemaError(ValueError):
    """Raised when an input file is missing required columns."""


def validate_schema(df: pd.DataFrame, require_label: bool = True) -> None:
    required = [c for c in C.REQUIRED_COLUMNS if require_label or c != C.TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise SchemaError(f"Input is missing required column(s): {missing}")


def _norm(value) -> str:
    return re.sub(r"[\s_\-]+", " ", str(value).strip().lower())


def standardise_category(series: pd.Series, canonical: list[str]) -> tuple[pd.Series, int, int]:
    """Map messy spellings to canonical labels. Returns (series, n_changed, n_unknown)."""
    lookup = {_norm(c): c for c in canonical}
    out, changed, unknown = [], 0, 0
    for v in series:
        if pd.isna(v):
            out.append(np.nan)
            continue
        mapped = lookup.get(_norm(v))
        if mapped is None:
            unknown += 1
            out.append(np.nan)
        else:
            if mapped != v:
                changed += 1
            out.append(mapped)
    return pd.Series(out, index=series.index, dtype=object), changed, unknown


_LABELS = {"yes": 1, "y": 1, "1": 1, "1.0": 1, "true": 1, "no": 0, "n": 0, "0": 0, "0.0": 0, "false": 0}


def clean(raw: pd.DataFrame, require_label: bool = True) -> tuple[pd.DataFrame, dict]:
    """Return (clean dataframe, quality report)."""
    validate_schema(raw, require_label)
    df = raw.copy()
    rep: dict = {"rows_in": int(len(df))}

    # --- duplicates
    before = len(df)
    df = df.drop_duplicates()
    rep["exact_duplicates_removed"] = int(before - len(df))
    before = len(df)
    df = df.drop_duplicates(subset=C.ID_COL, keep="first")
    rep["conflicting_id_duplicates_removed"] = int(before - len(df))
    df = df.reset_index(drop=True)

    # --- categoricals
    rep["category_values_standardised"] = {}
    rep["category_values_unknown_set_missing"] = {}
    for col, canon in C.CATEGORICAL.items():
        df[col], changed, unknown = standardise_category(df[col], canon)
        rep["category_values_standardised"][col] = changed
        rep["category_values_unknown_set_missing"][col] = unknown

    # --- numerics: coerce text, then range-check
    rep["non_numeric_text_set_missing"] = {}
    rep["out_of_range_set_missing"] = {}
    missing_before = {}
    for col in C.NUMERIC + C.BINARY:
        original = df[col]
        numeric = pd.to_numeric(original, errors="coerce")
        was_text = original.notna() & numeric.isna() & ~original.astype(str).str.strip().eq("")
        blank = original.astype(str).str.strip().eq("") & original.notna()
        rep["non_numeric_text_set_missing"][col] = int(was_text.sum() + blank.sum())
        df[col] = numeric
        missing_before[col] = int(df[col].isna().sum())
    for col, (lo, hi) in C.NUMERIC_BOUNDS.items():
        bad = df[col].notna() & ((df[col] < lo) | (df[col] > hi))
        rep["out_of_range_set_missing"][col] = int(bad.sum())
        df.loc[bad, col] = np.nan
    for col in C.BINARY:
        bad = df[col].notna() & ~df[col].isin([0, 1])
        rep["out_of_range_set_missing"][col] = int(bad.sum())
        df.loc[bad, col] = np.nan
    rep["unusable_cells_before_cleaning"] = {
        c: int(missing_before[c] + rep["out_of_range_set_missing"].get(c, 0))
        for c in missing_before if missing_before[c] + rep["out_of_range_set_missing"].get(c, 0) > 0}

    # --- deterministic cross-field repairs (total ~= monthly x tenure)
    rep["cross_field_repairs"] = {}
    m = df["monthly_charges"].isna() & df["total_charges"].notna() & df["tenure_months"].gt(0)
    df.loc[m, "monthly_charges"] = (df.loc[m, "total_charges"] / df.loc[m, "tenure_months"]).round(2)
    rep["cross_field_repairs"]["monthly_charges_from_total_and_tenure"] = int(m.sum())
    m = df["tenure_months"].isna() & df["total_charges"].notna() & df["monthly_charges"].gt(0)
    df.loc[m, "tenure_months"] = (df.loc[m, "total_charges"] / df.loc[m, "monthly_charges"]).round().clip(1, 120)
    rep["cross_field_repairs"]["tenure_from_total_and_monthly"] = int(m.sum())
    m = df["total_charges"].isna() & df["monthly_charges"].notna() & df["tenure_months"].notna()
    df.loc[m, "total_charges"] = (df.loc[m, "monthly_charges"] * df.loc[m, "tenure_months"]).round(2)
    rep["cross_field_repairs"]["total_from_monthly_and_tenure"] = int(m.sum())

    # consistency flag (reported, not changed)
    expected = df["monthly_charges"] * df["tenure_months"]
    inconsistent = expected.gt(0) & ((df["total_charges"] - expected).abs() / expected > 0.25)
    rep["total_charges_inconsistent_with_monthly_x_tenure"] = int(inconsistent.sum())

    # --- label
    if C.TARGET in df.columns:
        mapped = df[C.TARGET].map(lambda v: _LABELS.get(_norm(v)) if pd.notna(v) else np.nan)
        rep["label_unmapped_or_missing_rows_dropped"] = int(mapped.isna().sum())
        df[C.TARGET] = mapped
        if require_label:
            df = df[df[C.TARGET].notna()].copy()
            df[C.TARGET] = df[C.TARGET].astype(int)

    # --- integer-like columns
    for col in ["tenure_months", "support_tickets_90d", "logins_30d", "late_payments_6m", "age"]:
        df[col] = df[col].round()

    df = df.reset_index(drop=True)
    rep["rows_out"] = int(len(df))
    rep["missing_after_cleaning"] = {c: int(df[c].isna().sum()) for c in C.FEATURES if df[c].isna().any()}
    rep["missing_pct_after_cleaning"] = {c: round(100 * n / max(len(df), 1), 2)
                                         for c, n in rep["missing_after_cleaning"].items()}
    if C.TARGET in df.columns and require_label:
        rep["churn_rate"] = round(float(df[C.TARGET].mean()), 4)
    return df, rep


def main():
    import json
    raw = pd.read_csv(C.DATA_RAW / "churn_raw.csv", dtype={"total_charges": object, C.TARGET: object})
    df, rep = clean(raw)
    C.DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
    C.REPORTS.mkdir(parents=True, exist_ok=True)
    df.to_csv(C.DATA_PROCESSED / "churn_clean.csv", index=False)
    (C.REPORTS / "quality_report.json").write_text(json.dumps(rep, indent=2))
    print(json.dumps({k: rep[k] for k in ("rows_in", "rows_out", "churn_rate")}, indent=2))


if __name__ == "__main__":
    main()
