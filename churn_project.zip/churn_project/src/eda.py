"""Exploratory analysis organised around explicit business questions.

Each question produces (a) a figure and (b) a number that can be quoted in the report.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

from . import config as C

BLUE, ORANGE, GREY = "#2F6DB5", "#E4572E", "#8A8F98"
BUSINESS_QUESTIONS = {
    "Q1": "Who churns most - which contract, plan and payment groups?",
    "Q2": "How early in the lifecycle do customers leave?",
    "Q3": "Does service friction (support tickets, late payments) relate to churn?",
    "Q4": "Does product engagement (logins) separate churners from stayers?",
    "Q5": "Do price increases, discounts, autopay and referrals matter?",
    "Q6": "How much monthly revenue is lost to churn, and where is it concentrated?",
}


def _style():
    sns.set_theme(style="whitegrid", context="notebook")
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 110,
                         "axes.grid.axis": "y"})


def _save(fig, name):
    C.FIG.mkdir(parents=True, exist_ok=True)
    path = C.FIG / name
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def _rate_bar(ax, df, col, title, order=None):
    g = df.groupby(col, observed=True)[C.TARGET].agg(["mean", "size"]).reindex(order) if order else \
        df.groupby(col, observed=True)[C.TARGET].agg(["mean", "size"])
    ax.bar(g.index.astype(str), g["mean"] * 100, color=BLUE)
    for i, (r, n) in enumerate(zip(g["mean"], g["size"])):
        ax.text(i, r * 100 + 0.6, f"{r*100:.1f}%\n(n={n})", ha="center", fontsize=8,
                bbox=dict(fc="white", ec="none", pad=0.8, alpha=0.85), zorder=5)
    ax.axhline(df[C.TARGET].mean() * 100, color=ORANGE, ls="--", lw=1)
    ax.set_title(title)
    ax.set_ylabel("Churn rate (%)")
    ax.set_ylim(0, max(g["mean"]) * 100 * 1.25)
    return g


def missingness_plot(raw_missing: dict, after_missing: dict):
    _style()
    cols = sorted(set(raw_missing) | set(after_missing))
    fig, ax = plt.subplots(figsize=(8, 3.8))
    y = np.arange(len(cols))
    ax.barh(y + 0.2, [raw_missing.get(c, 0) for c in cols], height=0.4, color=GREY, label="Raw export")
    ax.barh(y - 0.2, [after_missing.get(c, 0) for c in cols], height=0.4, color=BLUE, label="After cleaning")
    ax.set_yticks(y)
    ax.set_yticklabels(cols)
    ax.set_xlabel("Missing or invalid cells")
    ax.set_title("Data quality: unusable values before and after cleaning")
    ax.legend(frameon=False)
    return _save(fig, "00_data_quality.png")


def run_eda(df: pd.DataFrame) -> pd.DataFrame:
    _style()
    d = df.copy()
    d["tenure_bucket"] = pd.cut(d["tenure_months"], [-1, 3, 6, 12, 24, 48, 200],
                                labels=["0-3", "4-6", "7-12", "13-24", "25-48", "49+"])
    out = {}

    # Q1 who churns most
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    out["contract"] = _rate_bar(axes[0], d, "contract", "Q1a Churn by contract", C.CONTRACTS)
    out["plan"] = _rate_bar(axes[1], d, "plan", "Q1b Churn by plan", C.PLANS)
    out["payment"] = _rate_bar(axes[2], d, "payment_method", "Q1c Churn by payment method")
    _save(fig, "01_who_churns.png")

    heat = d.pivot_table(index="plan", columns="contract", values=C.TARGET, aggfunc="mean").reindex(
        index=C.PLANS, columns=C.CONTRACTS) * 100
    fig, ax = plt.subplots(figsize=(6, 3.6))
    sns.heatmap(heat, annot=True, fmt=".1f", cmap="Oranges", cbar_kws={"label": "Churn %"}, ax=ax)
    ax.set_title("Q1d Churn % by plan x contract")
    _save(fig, "02_plan_contract_heatmap.png")

    # Q2 lifecycle
    fig, ax = plt.subplots(figsize=(7, 4))
    out["tenure"] = _rate_bar(ax, d, "tenure_bucket", "Q2 Churn by tenure (months)")
    _save(fig, "03_tenure.png")

    # Q3 service friction
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    t = d.assign(tk=d["support_tickets_90d"].clip(upper=5))
    out["tickets"] = _rate_bar(axes[0], t, "tk", "Q3a Churn by support tickets (90d, 5 = 5+)")
    l = d.assign(lt=d["late_payments_6m"].clip(upper=4))
    out["late"] = _rate_bar(axes[1], l, "lt", "Q3b Churn by late payments (6m, 4 = 4+)")
    _save(fig, "04_service_friction.png")

    # Q4 engagement
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.kdeplot(data=d, x="logins_30d", hue=d[C.TARGET].map({0: "Stayed", 1: "Churned"}),
                palette={"Stayed": BLUE, "Churned": ORANGE}, common_norm=False, fill=True, alpha=0.35, ax=ax)
    ax.set_title("Q4 Logins in last 30 days, churned vs stayed")
    _save(fig, "05_engagement.png")

    # Q5 price / discount / autopay / referral
    fig, axes = plt.subplots(1, 4, figsize=(14, 3.8))
    for ax, col in zip(axes, C.BINARY):
        out[col] = _rate_bar(ax, d.dropna(subset=[col]).assign(**{col: d[col].map({0: "No", 1: "Yes"})}), col,
                             f"Q5 {col}", ["No", "Yes"])
    _save(fig, "06_price_autopay.png")

    # Q6 revenue at risk
    lost = d[d[C.TARGET] == 1].groupby("contract")["monthly_charges"].sum().reindex(C.CONTRACTS)
    total_lost = d.loc[d[C.TARGET] == 1, "monthly_charges"].sum()
    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.bar(lost.index, lost.values, color=ORANGE)
    for i, v in enumerate(lost.values):
        ax.text(i, v * 1.01, f"{v/total_lost*100:.0f}%", ha="center", fontsize=9)
    ax.set_title("Q6 Monthly recurring revenue lost to churn, by contract")
    ax.set_ylabel("Monthly charges of churned customers")
    _save(fig, "07_revenue_lost.png")

    # correlation heat map
    num = d[C.NUMERIC + [C.TARGET]]
    fig, ax = plt.subplots(figsize=(8, 6.5))
    sns.heatmap(num.corr(method="spearman"), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax,
                annot_kws={"size": 7})
    ax.set_title("Spearman correlation (numeric features + churn)")
    _save(fig, "08_correlation.png")

    return statistical_tests(d)


def statistical_tests(df: pd.DataFrame) -> pd.DataFrame:
    """Association of every feature with churn. Effect sizes matter more than p-values at n=6000."""
    rows = []
    y = df[C.TARGET]
    for col in C.NUMERIC:
        x = df[col]
        m = x.notna()
        a, b = x[m & (y == 1)], x[m & (y == 0)]
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        auc = u / (len(a) * len(b))
        rows.append({"feature": col, "type": "numeric", "test": "Mann-Whitney U",
                     "effect_size": round(2 * auc - 1, 4), "effect_name": "Cliff's delta (churn>stay)",
                     "p_value": p, "median_churned": a.median(), "median_stayed": b.median()})
    for col in list(C.CATEGORICAL) + C.BINARY:
        sub = df.dropna(subset=[col])
        ct = pd.crosstab(sub[col], sub[C.TARGET])
        chi2, p, _, _ = stats.chi2_contingency(ct)
        v = np.sqrt(chi2 / (ct.values.sum() * (min(ct.shape) - 1)))
        rows.append({"feature": col, "type": "categorical", "test": "Chi-square",
                     "effect_size": round(float(v), 4), "effect_name": "Cramer's V", "p_value": p,
                     "median_churned": np.nan, "median_stayed": np.nan})
    res = pd.DataFrame(rows)
    res["p_bonferroni"] = (res["p_value"] * len(res)).clip(upper=1)
    res["abs_effect"] = res["effect_size"].abs()
    return res.sort_values("abs_effect", ascending=False).drop(columns="abs_effect").reset_index(drop=True)


def key_numbers(df: pd.DataFrame) -> dict:
    """Headline figures for the report."""
    y = df[C.TARGET]
    base = float(y.mean())
    mtm = df["contract"] == "Month-to-month"
    new = df["tenure_months"] <= 6
    lost = df.loc[y == 1, "monthly_charges"].sum()
    return {
        "n_customers": int(len(df)),
        "overall_churn_rate": round(base, 4),
        "churn_by_contract": df.groupby("contract")[C.TARGET].mean().round(4).to_dict(),
        "churn_by_plan": df.groupby("plan")[C.TARGET].mean().round(4).to_dict(),
        "churn_tenure_le6": round(float(y[new].mean()), 4),
        "churn_tenure_gt24": round(float(y[df["tenure_months"] > 24].mean()), 4),
        "churn_tickets_ge3": round(float(y[df["support_tickets_90d"] >= 3].mean()), 4),
        "churn_tickets_le1": round(float(y[df["support_tickets_90d"] <= 1].mean()), 4),
        "churn_late_ge2": round(float(y[df["late_payments_6m"] >= 2].mean()), 4),
        "churn_late_0": round(float(y[df["late_payments_6m"] == 0].mean()), 4),
        "churn_autopay": round(float(y[df["autopay"] == 1].mean()), 4),
        "churn_no_autopay": round(float(y[df["autopay"] == 0].mean()), 4),
        "churn_price_increase": round(float(y[df["price_increase_recent"] == 1].mean()), 4),
        "churn_no_price_increase": round(float(y[df["price_increase_recent"] == 0].mean()), 4),
        "median_logins_churned": float(df.loc[y == 1, "logins_30d"].median()),
        "median_logins_stayed": float(df.loc[y == 0, "logins_30d"].median()),
        "monthly_revenue_lost": round(float(lost), 2),
        "revenue_lost_share_month_to_month": round(float(df.loc[(y == 1) & mtm, "monthly_charges"].sum() / lost), 4),
        "month_to_month_share_of_customers": round(float(mtm.mean()), 4),
    }


def main():
    import json
    df = pd.read_csv(C.DATA_PROCESSED / "churn_clean.csv")
    stats_df = run_eda(df)
    C.REPORTS.mkdir(parents=True, exist_ok=True)
    stats_df.to_csv(C.REPORTS / "eda_stats.csv", index=False)
    (C.REPORTS / "key_numbers.json").write_text(json.dumps(key_numbers(df), indent=2))
    print(stats_df[["feature", "effect_size", "p_bonferroni"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
