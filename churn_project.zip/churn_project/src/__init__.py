"""Customer Churn Investigation - reusable pipeline package."""
