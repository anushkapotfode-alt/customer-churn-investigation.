"""Central configuration: paths, schema, valid ranges and business assumptions.

Everything a reviewer might want to challenge lives here, not buried in code.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
OUT = ROOT / "outputs"
FIG = OUT / "figures"
REPORTS = OUT / "reports"
MODELS = OUT / "models"

SEED = 42
N_CUSTOMERS = 6000
TARGET_CHURN_RATE = 0.27          # used only to calibrate the simulator
SIM_INTERCEPT = -1.3295           # from generate_data.calibrate_intercept(); pinned for reproducibility

# ---------------------------------------------------------------- schema
PLANS = ["Basic", "Standard", "Premium"]
CONTRACTS = ["Month-to-month", "One year", "Two year"]
PAYMENTS = ["Card", "UPI", "Bank Transfer", "Wallet"]
REGIONS = ["North", "South", "East", "West"]

CATEGORICAL = {
    "plan": PLANS,
    "contract": CONTRACTS,
    "payment_method": PAYMENTS,
    "region": REGIONS,
}
NUMERIC = [
    "age", "tenure_months", "monthly_charges", "total_charges",
    "support_tickets_90d", "logins_30d", "avg_session_min", "late_payments_6m",
]
BINARY = ["autopay", "price_increase_recent", "discount_flag", "referred"]
ID_COL = "customer_id"
TARGET = "churned"

REQUIRED_COLUMNS = [ID_COL] + list(CATEGORICAL) + NUMERIC + BINARY + [TARGET]
FEATURES = list(CATEGORICAL) + NUMERIC + BINARY       # model inputs (no id, no target)

# Plausible ranges. Values outside become missing (never silently kept).
NUMERIC_BOUNDS = {
    "age": (18, 100),
    "tenure_months": (0, 120),
    "monthly_charges": (5, 300),
    "total_charges": (0, 40000),
    "support_tickets_90d": (0, 50),
    "logins_30d": (0, 300),
    "avg_session_min": (0, 300),
    "late_payments_6m": (0, 6),
}

# ---------------------------------------------------------------- business assumptions
# ILLUSTRATIVE - replace with finance-approved numbers before using for decisions.
CAMPAIGN_BUDGET_FRACTION = 0.20   # retention team can contact 20% of the base
OFFER_COST_PER_CUSTOMER = 5.0     # cost of a retention offer / call (currency units)
SAVE_RATE = 0.30                  # share of contacted would-be churners who are retained
GROSS_MARGIN = 0.60
VALUE_MONTHS = 12                 # months of margin a saved customer is assumed to keep paying

# ---------------------------------------------------------------- monitoring
PSI_WARN = 0.10
PSI_ALERT = 0.25
