"""Extension: drift monitoring (PSI) and a before/after evaluation on a drifted cohort."""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from . import config as C
from . import generate_data as G
from .clean import clean
from .model import build_model, evaluate, split


def _psi_from_pct(e, a):
    e, a = np.clip(e, 1e-4, None), np.clip(a, 1e-4, None)
    return float(np.sum((a - e) * np.log(a / e)))


def psi_numeric(expected: pd.Series, actual: pd.Series, bins: int = 10) -> float:
    e, a = expected.dropna().to_numpy(float), actual.dropna().to_numpy(float)
    edges = np.unique(np.quantile(e, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:                              # near-constant feature
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    return _psi_from_pct(np.histogram(e, edges)[0] / len(e), np.histogram(a, edges)[0] / len(a))


def psi_categorical(expected: pd.Series, actual: pd.Series) -> float:
    cats = sorted(set(expected.dropna().unique()) | set(actual.dropna().unique()), key=str)
    e = expected.value_counts(normalize=True).reindex(cats).fillna(0).to_numpy()
    a = actual.value_counts(normalize=True).reindex(cats).fillna(0).to_numpy()
    return _psi_from_pct(e, a)


def status(psi: float) -> str:
    return "ALERT" if psi >= C.PSI_ALERT else "WARN" if psi >= C.PSI_WARN else "ok"


def drift_report(ref: pd.DataFrame, cur: pd.DataFrame, extra_scores: tuple | None = None) -> pd.DataFrame:
    rows = []
    for col in C.NUMERIC:
        v = psi_numeric(ref[col], cur[col])
        rows.append({"feature": col, "psi": round(v, 4), "status": status(v)})
    for col in list(C.CATEGORICAL) + C.BINARY:
        v = psi_categorical(ref[col], cur[col])
        rows.append({"feature": col, "psi": round(v, 4), "status": status(v)})
    if extra_scores is not None:
        v = psi_numeric(pd.Series(extra_scores[0]), pd.Series(extra_scores[1]))
        rows.append({"feature": "MODEL SCORE", "psi": round(v, 4), "status": status(v)})
    return pd.DataFrame(rows).sort_values("psi", ascending=False).reset_index(drop=True)


DRIFT_SCENARIOS = {
    # customers change (less engaged, more price increases) but the churn mechanism is the same
    "A_covariate_shift": {"engagement_shift": -0.6, "price_increase_rate": 0.45, "ticket_shift": 0.4},
    # the mechanism itself changes: price increases hurt far more, contract lock-in protects less
    "B_concept_drift": {"engagement_shift": -0.6, "price_increase_rate": 0.45, "ticket_shift": 0.4,
                        "price_effect": 1.8, "mtm_effect": 0.3},
}


def before_after_experiment(model, ref_clean: pd.DataFrame, scenario: str, seed: int = C.SEED) -> dict:
    """BEFORE: the original model keeps running, unmonitored, on a drifted cohort.
    AFTER: monitoring raises alerts; we retrain on recent data and compare on the same hold-out."""
    drift = DRIFT_SCENARIOS[scenario]
    drifted_true = G.simulate(n=3000, seed=seed + 7, drift=drift)
    raw, _ = G.make_raw(drifted_true, seed=seed + 7)
    cur, _ = clean(raw)
    p_ref = model.predict_proba(ref_clean[C.FEATURES])[:, 1]
    p_cur = model.predict_proba(cur[C.FEATURES])[:, 1]
    report = drift_report(ref_clean, cur, extra_scores=(p_ref, p_cur))

    X_tr, X_te, y_tr, y_te = split(cur, seed)
    stale = model.predict_proba(X_te)[:, 1]
    retrained = build_model("logistic", seed).fit(X_tr, y_tr)
    fresh = retrained.predict_proba(X_te)[:, 1]
    res = {
        "scenario": scenario,
        "drift_parameters": drift,
        "reference_churn_rate": float(ref_clean[C.TARGET].mean()),
        "new_cohort_churn_rate": float(cur[C.TARGET].mean()),
        "mean_predicted_by_stale_model": float(stale.mean()),
        "mean_predicted_by_retrained_model": float(fresh.mean()),
        "observed_churn_rate_holdout": float(y_te.mean()),
        "before_stale_model": evaluate(y_te, stale),
        "after_retrained_model": evaluate(y_te, fresh),
        "alerts": report[report["status"] == "ALERT"]["feature"].tolist(),
        "warnings": report[report["status"] == "WARN"]["feature"].tolist(),
        "n_retrain": int(len(X_tr)), "n_holdout": int(len(X_te)),
    }
    return {"report": report, "result": res}


def plot_drift(outs: dict):
    C.FIG.mkdir(parents=True, exist_ok=True)
    colors = {"ok": "#8A8F98", "WARN": "#F2A900", "ALERT": "#E4572E"}
    fig, axes = plt.subplots(len(outs), 2, figsize=(13, 4.6 * len(outs)), gridspec_kw={"width_ratios": [1.3, 1]})
    for row, (name, o) in zip(axes, outs.items()):
        rep, res = o["report"], o["result"]
        r = rep.iloc[::-1]
        row[0].barh(r["feature"], r["psi"], color=[colors[s] for s in r["status"]])
        row[0].axvline(C.PSI_WARN, color="#F2A900", ls="--", lw=1)
        row[0].axvline(C.PSI_ALERT, color="#E4572E", ls="--", lw=1)
        row[0].set_xlabel("PSI vs reference (amber >= 0.10, red >= 0.25)")
        row[0].set_title(f"Scenario {name}: drift monitor")
        w = 0.36
        metrics = [("ROC-AUC", "roc_auc"), ("Top-20% recall", "top20_recall")]
        x = np.arange(len(metrics))
        b = [res["before_stale_model"][m] for _, m in metrics]
        a = [res["after_retrained_model"][m] for _, m in metrics]
        row[1].bar(x - w / 2, b, w, color="#8A8F98", label="Before: original model")
        row[1].bar(x + w / 2, a, w, color="#2F6DB5", label="After: retrained")
        for i, (bv, av) in enumerate(zip(b, a)):
            row[1].text(i - w / 2, bv + 0.01, f"{bv:.3f}", ha="center", fontsize=8)
            row[1].text(i + w / 2, av + 0.01, f"{av:.3f}", ha="center", fontsize=8)
        row[1].set_xticks(x)
        row[1].set_xticklabels([m for m, _ in metrics])
        row[1].set_ylim(0, 1)
        row[1].set_title("Hold-out performance on the new cohort")
        row[1].legend(frameon=False, loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(C.FIG / "12_drift_monitoring.png", dpi=130)
    plt.close(fig)


def main():
    import joblib
    ref = pd.read_csv(C.DATA_PROCESSED / "churn_clean.csv")
    model = joblib.load(C.MODELS / "churn_model.joblib")["pipeline"]
    outs = {name: before_after_experiment(model, ref, name) for name in DRIFT_SCENARIOS}
    pd.concat([o["report"].assign(scenario=n) for n, o in outs.items()]).to_csv(C.REPORTS / "drift_report.csv", index=False)
    (C.REPORTS / "before_after.json").write_text(json.dumps({n: o["result"] for n, o in outs.items()}, indent=2))
    plot_drift(outs)
    for n, o in outs.items():
        r = o["result"]
        print(n, "alerts:", r["alerts"], "warn:", r["warnings"])
        print("  churn ref/new:", round(r["reference_churn_rate"], 3), round(r["new_cohort_churn_rate"], 3),
              "| stale predicts", round(r["mean_predicted_by_stale_model"], 3), "retrained", round(r["mean_predicted_by_retrained_model"], 3),
              "observed", round(r["observed_churn_rate_holdout"], 3))
        for k in ("before_stale_model", "after_retrained_model"):
            print("  ", k, {m: round(v, 3) for m, v in r[k].items() if m in ("roc_auc", "pr_auc", "top20_recall", "top20_lift")})


if __name__ == "__main__":
    main()
