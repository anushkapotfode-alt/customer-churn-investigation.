"""Score a new customer file with the saved model.

    python -m src.score --input new_customers.csv --output risk_list.csv

Validates the schema, applies the same cleaning rules, and tolerates unseen categories and
missing values. The label column is NOT required.
"""
from __future__ import annotations

import argparse
import sys

import joblib
import numpy as np
import pandas as pd

from . import config as C
from .clean import SchemaError, clean


def risk_flags(row: pd.Series) -> str:
    flags = []
    if row["contract"] == "Month-to-month":
        flags.append("month-to-month")
    if row["tenure_months"] <= 6:
        flags.append("new customer")
    if row["support_tickets_90d"] >= 3:
        flags.append("many support tickets")
    if row["late_payments_6m"] >= 2:
        flags.append("late payments")
    if row["autopay"] == 0:
        flags.append("no autopay")
    if row["price_increase_recent"] == 1:
        flags.append("recent price increase")
    if row["logins_30d"] <= 8:
        flags.append("low engagement")
    return "; ".join(flags)


def score_dataframe(raw: pd.DataFrame, bundle: dict) -> pd.DataFrame:
    df, _ = clean(raw, require_label=False)
    p = bundle["pipeline"].predict_proba(df[C.FEATURES])[:, 1]
    bands = bundle["meta"]["risk_bands"]
    out = pd.DataFrame({C.ID_COL: df[C.ID_COL], "churn_probability": np.round(p, 4)})
    out["risk_band"] = np.where(p >= bands["high_threshold"], "High",
                                np.where(p >= bands["medium_threshold"], "Medium", "Low"))
    out["monthly_charges"] = df["monthly_charges"]
    out["risk_flags"] = df.apply(risk_flags, axis=1)
    return out.sort_values("churn_probability", ascending=False).reset_index(drop=True)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--model", default=str(C.MODELS / "churn_model.joblib"))
    args = ap.parse_args(argv)
    bundle = joblib.load(args.model)
    raw = pd.read_csv(args.input, dtype={"total_charges": object})
    try:
        out = score_dataframe(raw, bundle)
    except SchemaError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    out.to_csv(args.output, index=False)
    print(f"scored {len(out)} customers -> {args.output}  (High: {(out.risk_band == 'High').sum()})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
