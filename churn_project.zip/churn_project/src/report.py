"""Build outputs/final_report.md from the saved result files.

Every number in the report is read from outputs/reports/*.json|csv, so the text cannot drift out
of sync with the analysis. Re-run `python run_pipeline.py` and the report regenerates.
"""
from __future__ import annotations

import json

import pandas as pd

from . import config as C
from .eda import BUSINESS_QUESTIONS

ACTIONS = [  # direction-aware: first match wins, so "low tickets" never triggers the service-recovery action
    ("high tickets", "Service recovery: proactive outreach after the 2nd ticket, named support owner, fix root causes."),
    ("high late payments", "Billing fixes: autopay nudges, flexible due dates, reminder cadence before the due date."),
    ("high spend", "Protect high-value accounts: account-manager check-ins and plan-fit reviews before renewal."),
    ("high tenure", "Loyalty protection: low-touch recognition; do not spend discount budget here."),
    ("high logins", "Lock-in: offer annual/two-year contract incentives while engagement is high."),
    ("high session", "Lock-in: offer annual/two-year contract incentives while engagement is high."),
    ("low logins", "Re-engagement: onboarding/usage nudges and feature education in the first weeks."),
    ("low session", "Re-engagement: onboarding/usage nudges and feature education in the first weeks."),
    ("low tenure", "Early-life programme: onboarding check-ins and quick-win guidance in the first 90 days."),
]


def _action(desc: str) -> str:
    for kw, act in ACTIONS:
        if kw in desc:
            return act
    return "Monitor; no targeted action."


NICE = {"logistic": "Logistic regression", "gradient_boosting": "Gradient boosting"}


def pct(x, d=1):
    return f"{100*x:.{d}f}%"


def _md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r.values) + " |")
    return "\n".join(lines)


def build() -> str:
    R = C.REPORTS
    q = json.loads((R / "quality_report.json").read_text())
    k = json.loads((R / "key_numbers.json").read_text())
    m = json.loads((R / "model_metrics.json").read_text())
    ba = json.loads((R / "before_after.json").read_text())
    seg_meta = json.loads((R / "segmentation_meta.json").read_text())
    truth = json.loads((R / "simulation_truth.json").read_text())
    seg = pd.read_csv(R / "segment_profiles.csv")
    eda_stats = pd.read_csv(R / "eda_stats.csv")
    imp = pd.read_csv(R / "permutation_importance.csv")
    drift = pd.read_csv(R / "drift_report.csv")

    ch = m["chosen_model"]
    t = m["test"]
    biz = m["business_case_top20"]
    ci = m["confidence_intervals"]
    a, b = ba["A_covariate_shift"], ba["B_concept_drift"]
    top_imp = ", ".join(imp["feature"].head(4))

    seg_tbl = seg.assign(
        Segment=seg["segment_name"], Customers=seg["customers"],
        **{"Churn rate": seg["churn_rate"].map(pct), "Avg tenure (mo)": seg["avg_tenure"].round(1),
           "Avg monthly charge": seg["avg_monthly_charges"].round(1),
           "Share of revenue lost": seg["share_of_revenue_lost"].map(lambda v: pct(v, 0)),
           "Profile": seg["description"], "Suggested retention action": seg["description"].map(_action)},
    )[["Segment", "Customers", "Churn rate", "Avg tenure (mo)", "Avg monthly charge", "Share of revenue lost",
       "Profile", "Suggested retention action"]]

    model_rows = []
    for name, label in [("random", "Random targeting"), ("rule_baseline", "Rule-of-thumb (risk-flag count)"),
                        ("logistic", "Logistic regression"), ("gradient_boosting", "Gradient boosting")]:
        r = t[name]
        tag = " (chosen)" if name == ch else ""
        model_rows.append({"Approach": label + tag, "ROC-AUC": f"{r['roc_auc']:.3f}", "PR-AUC": f"{r['pr_auc']:.3f}",
                           "Top-20% precision": pct(r["top20_precision"]), "Top-20% churners reached": pct(r["top20_recall"]),
                           "Lift": f"{r['top20_lift']:.2f}x"})
    model_tbl = _md_table(pd.DataFrame(model_rows))

    biz_tbl = _md_table(pd.DataFrame([
        {"Targeting": lbl, "Customers contacted": v["contacted"], "Expected saved": f"{v['expected_customers_saved']:.0f}",
         "Margin retained": f"{v['expected_margin_retained']:,.0f}", "Cost": f"{v['campaign_cost']:,.0f}",
         "Net value": f"{v['net_value']:,.0f}"}
        for lbl, v in [("Random", biz["random"]), ("Rule-of-thumb", biz["rule_baseline"]), ("Model", biz["model"])]]))

    eff_tbl = _md_table(eda_stats.head(8).assign(
        effect_size=eda_stats["effect_size"].round(3),
        p_bonferroni=eda_stats["p_bonferroni"].map(lambda v: "<0.001" if v < 0.001 else f"{v:.3f}"))[
        ["feature", "effect_name", "effect_size", "p_bonferroni"]].rename(
        columns={"effect_name": "Effect size type", "effect_size": "Effect", "p_bonferroni": "p (Bonferroni)"}))

    drift_a = drift[(drift["scenario"] == "A_covariate_shift")].head(5)[["feature", "psi", "status"]]
    ba_tbl = _md_table(pd.DataFrame([
        {"Scenario": "A: customers change, mechanism same", "Model": lbl,
         "ROC-AUC": f"{r['roc_auc']:.3f}", "Top-20% recall": pct(r["top20_recall"])}
        for lbl, r in [("Original (before)", a["before_stale_model"]), ("Retrained (after)", a["after_retrained_model"])]]
        + [{"Scenario": "B: churn mechanism changes", "Model": lbl, "ROC-AUC": f"{r['roc_auc']:.3f}",
            "Top-20% recall": pct(r["top20_recall"])}
           for lbl, r in [("Original (before)", b["before_stale_model"]), ("Retrained (after)", b["after_retrained_model"])]]))

    da = a["after_retrained_model"]["roc_auc"] - a["before_stale_model"]["roc_auc"]
    db = b["after_retrained_model"]["roc_auc"] - b["before_stale_model"]["roc_auc"]
    A_TEXT = (f"In scenario A the original model did about as well as a retrained one (ROC-AUC {a['before_stale_model']['roc_auc']:.3f} "
              f"vs {a['after_retrained_model']['roc_auc']:.3f}), so retraining would not have paid off." if da < 0.01 else
              f"In scenario A retraining improved ROC-AUC by {da:.3f}.")
    B_TEXT = (f"In scenario B performance dropped and retraining recovered it (ROC-AUC {b['before_stale_model']['roc_auc']:.3f} -> "
              f"{b['after_retrained_model']['roc_auc']:.3f})." if db > 0.02 else
              f"In scenario B retraining changed ROC-AUC by only {db:+.3f}.")

    md = f"""# Customer Churn Investigation - Final Report

*Arrowstack Data Science internship, Project 1. All data is simulated; no real customers are involved.*

## 1. Executive summary

- **Problem.** A subscription business loses **{pct(k['overall_churn_rate'])}** of customers. The retention team can contact only
  **{pct(C.CAMPAIGN_BUDGET_FRACTION, 0)}** of the base, so the question is *who* to contact and *what* to offer.
- **Who churns.** Month-to-month contracts churn at **{pct(k['churn_by_contract']['Month-to-month'])}** versus
  **{pct(k['churn_by_contract']['Two year'])}** on two-year contracts. They are {pct(k['month_to_month_share_of_customers'], 0)} of customers
  but **{pct(k['revenue_lost_share_month_to_month'], 0)}** of monthly revenue lost. Customers in their first 6 months churn at
  {pct(k['churn_tenure_le6'])} (versus {pct(k['churn_tenure_gt24'])} after 24 months).
- **Why (associations).** Short tenure, low logins, 3+ support tickets, late payments, no autopay and a recent price increase
  all go with higher churn. These are associations in simulated data, not proven causes.
- **Segments.** Six behavioural segments with churn from {pct(seg['churn_rate'].min())} to {pct(seg['churn_rate'].max())},
  stable under resampling (ARI {seg_meta['stability_ARI_mean']:.2f}).
- **Model.** {NICE[ch]} reaches ROC-AUC **{t[ch]['roc_auc']:.3f}** on a held-out test set
  (95% CI {ci['model_roc_auc_ci95'][0]:.3f}-{ci['model_roc_auc_ci95'][1]:.3f}); contacting the top 20% by risk reaches
  **{pct(t[ch]['top20_recall'], 0)}** of churners versus {pct(t['random']['top20_recall'], 0)} at random and
  {pct(t['rule_baseline']['top20_recall'], 0)} for a simple rule-of-thumb.
- **Honest caveat.** The rule-of-thumb already captures most of the value. Under the illustrative assumptions below the model adds
  {biz['model']['net_value'] - biz['rule_baseline']['net_value']:,.0f} net value over it on a {m['n_test']}-customer test set; the gain in
  churners reached has a 95% CI of {ci['recall_gain_vs_rule_top20_ci95'][0]*100:+.1f} to {ci['recall_gain_vs_rule_top20_ci95'][1]*100:+.1f} percentage points.

## 2. Stakeholder, decision and success criteria (defined before analysis)

- **Primary stakeholder:** Retention Manager. **Secondary:** Finance Analyst (revenue at risk, campaign ROI).
- **Decision enabled:** which customers to contact in each campaign cycle, and which action to take per segment.
- **Success criteria:** (1) data issues documented and handled; (2) model beats a rule-of-thumb baseline on held-out data;
  (3) probabilities are calibrated well enough to rank *and* to estimate revenue at risk; (4) every insight maps to a retention action;
  (5) the work is reproducible with one command.

## 3. Data and quality

Raw export: **{q['rows_in']:,}** rows. After cleaning: **{q['rows_out']:,}** customers.

| Check | Result |
|---|---|
| Exact duplicate rows removed | {q['exact_duplicates_removed']} |
| Conflicting duplicate customer ids removed (kept first) | {q['conflicting_id_duplicates_removed']} |
| Category spellings standardised (case/whitespace/hyphens) | {sum(q['category_values_standardised'].values())} |
| Text in numeric columns set to missing | {sum(q['non_numeric_text_set_missing'].values())} |
| Out-of-range values set to missing | {sum(q['out_of_range_set_missing'].values())} |
| Cross-field repairs (total = monthly x tenure) | {sum(q['cross_field_repairs'].values())} |
| Rows dropped for missing/unreadable label | {q['label_unmapped_or_missing_rows_dropped']} |
| Remaining missing values (imputed inside the model pipeline) | {sum(q['missing_after_cleaning'].values())} cells, max {max(q['missing_pct_after_cleaning'].values()):.1f}% in any column |

The simulator recorded exactly what it corrupted ({truth['exact_duplicates']} exact duplicates, {truth['conflicting_id_duplicates']} conflicting
duplicates, {truth['label_missing']} missing labels), so detection counts can be audited against ground truth (see `tests/`).
See `docs/data_dictionary.md` for every column.

![data quality](figures/00_data_quality.png)

## 4. Business questions and findings

""" + "\n".join(f"- **{qid}.** {qtext}" for qid, qtext in BUSINESS_QUESTIONS.items()) + f"""

**Q1 Who churns most.** Contract is the strongest group difference ({pct(k['churn_by_contract']['Month-to-month'])} /
{pct(k['churn_by_contract']['One year'])} / {pct(k['churn_by_contract']['Two year'])} for month-to-month / one-year / two-year).
Basic plan churns {pct(k['churn_by_plan']['Basic'])} versus {pct(k['churn_by_plan']['Premium'])} for Premium.
![who churns](figures/01_who_churns.png)

**Q2 Lifecycle.** Early life is the danger zone: {pct(k['churn_tenure_le6'])} churn in the first 6 months.
![tenure](figures/03_tenure.png)

**Q3 Service friction.** 3+ tickets in 90 days: {pct(k['churn_tickets_ge3'])} churn (vs {pct(k['churn_tickets_le1'])} for 0-1).
2+ late payments: {pct(k['churn_late_ge2'])} (vs {pct(k['churn_late_0'])} for none).
![friction](figures/04_service_friction.png)

**Q4 Engagement.** Median logins: {k['median_logins_churned']:.0f} for churners vs {k['median_logins_stayed']:.0f} for stayers.
![engagement](figures/05_engagement.png)

**Q5 Price, autopay and incentives.** Recent price increase: {pct(k['churn_price_increase'])} vs {pct(k['churn_no_price_increase'])}.
Autopay: {pct(k['churn_autopay'])} vs {pct(k['churn_no_autopay'])} without it.
![price and autopay](figures/06_price_autopay.png)

**Q6 Revenue.** Churned customers represented **{k['monthly_revenue_lost']:,.0f}** in monthly charges.
![revenue lost](figures/07_revenue_lost.png)

**Strength of evidence.** With ~6,000 rows nearly every feature is statistically significant, so effect sizes are the useful ranking:

{eff_tbl}

## 5. Customer segments

KMeans (k={seg_meta['k']}, chosen by silhouette over k=3-6) on tenure, spend, logins, session length, tickets and late payments.
The label is *not* used for clustering. Silhouette is low and flat across k ({', '.join(f'{kk}: {v:.2f}' for kk, v in seg_meta['silhouette_by_k'].items())}),
meaning these are practical operating groups rather than sharply separated natural clusters; they are, however, reproducible
(ARI {seg_meta['stability_ARI_mean']:.2f} mean, {seg_meta['stability_ARI_min']:.2f} minimum over five 80% subsamples).

{_md_table(seg_tbl)}

![segments](figures/09_segments.png)

## 6. Churn prediction

**Method.** 80/20 stratified split. Imputation, scaling and one-hot encoding live inside the pipeline, so they are fitted on training folds only.
Model choice used 5-fold CV on the training set with a rule fixed in advance: take logistic regression unless gradient boosting is better
by more than 0.01 CV ROC-AUC (CV: logistic {m['cv']['logistic']['roc_auc_mean']:.3f}, boosting {m['cv']['gradient_boosting']['roc_auc_mean']:.3f}).
The test set was used once, afterwards.

{model_tbl}

Test set: {m['n_test']} customers, churn rate {pct(m['test_churn_rate'])}. Brier score {m['brier_score']:.3f}
(always predicting the base rate: {m['brier_baseline_prevalence']:.3f}). Average gap between predicted and observed churn across
deciles: {m['calibration_mean_abs_gap']*100:.1f} percentage points.

**Most important inputs (permutation importance):** {top_imp}.
![model](figures/10_model_evaluation.png)
![logistic effects](figures/11_logistic_effects.png)

### Retention business case (illustrative assumptions)

Contact the top {pct(C.CAMPAIGN_BUDGET_FRACTION, 0)} by risk, evaluated on the {m['n_test']}-customer test set. Assumptions (edit `src/config.py`; replace with finance-approved numbers):
offer cost {C.OFFER_COST_PER_CUSTOMER:.0f} per customer, {pct(C.SAVE_RATE, 0)} of contacted would-be churners are retained,
gross margin {pct(C.GROSS_MARGIN, 0)}, retained customers pay {C.VALUE_MONTHS} more months.

{biz_tbl}

## 7. Extension: monitoring and before/after evaluation

**Monitor.** Population Stability Index (PSI) per feature and on the model score; amber at {C.PSI_WARN}, red at {C.PSI_ALERT}.
Two simulated "next-quarter" cohorts of 3,000 customers were scored:

- **A. Customers change, mechanism unchanged** (lower engagement, more price increases).
- **B. The churn mechanism itself changes** (price increases hurt much more; contract lock-in protects less).

{ba_tbl}

What this shows:

1. PSI raised the **same alerts in both scenarios** ({', '.join(a['alerts'])}). Input drift tells you *that something changed*, not whether
   the model got worse.
2. {A_TEXT}
3. {B_TEXT}
4. Therefore the monitoring rule is: *drift alert -> check realised performance on newly labelled customers -> retrain only if it degrades.*
   Labels arrive with a lag, so a lag-aware performance check is part of the roadmap.

Top input-drift rows, scenario A:

{_md_table(drift_a)}

![drift](figures/12_drift_monitoring.png)

**Automation.** `python run_pipeline.py` regenerates every table, figure, model and this report in about 10 seconds on the
development machine (measured). Compare that with your own estimate of the manual notebook process to quantify the productivity gain
for your write-up. `python -m src.score` produces a ranked risk list from a new customer file, with schema validation and
unseen-category handling.

## 8. Limitations

- **Simulated data.** Effects are as realistic as the simulator, not as realistic as a real business. The model recovers the simulator's
  mechanism; results on real data would differ and need re-validation.
- **Associations, not causes.** A discount flag with lower churn does not prove discounts cause retention (customers who were offered discounts may differ).
- **Business-case numbers are assumptions.** Save rate, cost and margin are placeholders; net value scales directly with them.
- **No lifetime view.** Churn here is a single binary outcome; there is no time-to-event modelling, so "when" is only approximated by tenure.
- **Segments are weakly separated** (low silhouette) and named automatically from their strongest features.
- **Duplicate handling keeps the first record** for conflicting ids; in real data the source of truth should decide.
- **Fairness.** Age and region are inputs. Before real use, check outcomes across groups and consider removing sensitive attributes.

## 9. Recommendations and next steps

1. Pilot the model-ranked list on the top {pct(C.CAMPAIGN_BUDGET_FRACTION, 0)} with a **randomised holdout** so uplift (not just churn risk) is measured.
2. Use the segment actions in section 5; start with the highest churn / highest revenue-at-risk segments.
3. Add an early-life programme (first 90 days) and a price-increase communication plan.
4. Move from "who will churn" to "who can be saved" (uplift modelling) once pilot data exist.
5. Productionise per `docs/limitations_and_roadmap.md` (security, scalability, governance, maintainability).
"""
    (C.OUT / "final_report.md").write_text(md)
    return md


if __name__ == "__main__":
    build()
    print("wrote", C.OUT / "final_report.md")
