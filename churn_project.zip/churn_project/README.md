# Customer Churn Investigation

Arrowstack Data Science Internship - **Project 1**. A simulated subscription business loses ~28% of its customers.
This project finds the churn drivers, segments customers, ranks who to contact, and proposes retention actions.
**All data is simulated** (no real customers, no real systems).

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_pipeline.py          # ~10 s: data -> cleaning -> EDA -> segments -> model -> monitoring -> report
python -m pytest -q             # 25 tests
```

Open **`outputs/final_report.md`** for the findings, or **`notebooks/churn_investigation.ipynb`** for the walk-through.
Everything is seeded (`SEED = 42` in `src/config.py`); two runs produce identical results.

## Score new customers

```bash
python -m src.score --input data/raw/churn_raw.csv --output outputs/risk_list.csv
```
Validates the schema, applies the same cleaning rules, tolerates missing values and unseen categories, and writes a ranked list
with `churn_probability`, `risk_band` (High = top 10%, Medium = next 20%) and plain-language `risk_flags`.
A missing required column exits with code 2 and a clear message. A label column is not required.

## Project map

| Path | What it is |
|---|---|
| `run_pipeline.py` | One command that runs everything |
| `src/config.py` | Schema, valid ranges, business assumptions, thresholds (change assumptions here) |
| `src/generate_data.py` | Simulator + realistic corruption (duplicates, typos, impossible values, mixed labels) |
| `src/clean.py` | Cleaning, quality checks, counted report |
| `src/eda.py` | EDA organised around six business questions, effect-size tests |
| `src/segment.py` | KMeans segments + stability check |
| `src/model.py` | Baselines, logistic regression, gradient boosting, CV, calibration, importance, business case |
| `src/monitor.py` | Extension: PSI drift monitor and before/after experiment |
| `src/score.py` | CLI to score a new file |
| `src/report.py` | Builds the final report from saved results (numbers can't drift from the analysis) |
| `tests/` | 25 pytest tests (cleaning vs ground truth, leakage guard, model quality, PSI, CLI) |
| `docs/` | Requirements, data dictionary, decision log, validation evidence, limitations & roadmap, work log, viva & portfolio prep |
| `data/raw/churn_raw.csv` | Messy simulated export |
| `data/processed/` | Cleaned data and segment assignments |
| `data/ground_truth/` | The simulator's clean answer key, for auditing the cleaning only - never used as model input |
| `outputs/` | Figures, JSON/CSV reports, saved model, final report |

## Headline results (seed 42)

- Churn: 27.7% overall; month-to-month 39.7% vs two-year ~7%.
- Held-out ROC-AUC 0.805 (logistic regression) vs 0.738 for a rule-of-thumb and 0.52 random.
- Contacting the top 20% by risk reaches 45% of churners (rule-of-thumb 39%, random 18%).
- Honest caveat: the rule-of-thumb captures most of the business value; the model's edge is real but modest.

## Responsible use

Simulated data only. Business-case numbers (offer cost, save rate, margin) are **placeholders**. Age and region are model inputs; run a
fairness review before any real deployment. See `docs/limitations_and_roadmap.md`.
