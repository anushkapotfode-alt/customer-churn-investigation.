"""Run the whole project end to end:  python run_pipeline.py

Stages: simulate raw data -> clean + quality report -> EDA -> segmentation -> model ->
monitoring extension -> final report. Everything is seeded; two runs give identical outputs.
"""
import json
import time

import joblib
import pandas as pd

from src import config as C
from src import eda, generate_data as G, monitor, report, segment
from src.clean import clean
from src.model import plot_model, train_and_evaluate


def step(name):
    print(f"\n=== {name}")
    return time.time()


def main():
    for d in (C.DATA_RAW, C.DATA_PROCESSED, C.FIG, C.REPORTS, C.MODELS):
        d.mkdir(parents=True, exist_ok=True)

    t = step("1/6 Simulate raw data (messy export)")
    truth_clean = G.simulate()
    raw, truth = G.make_raw(truth_clean)
    raw.to_csv(C.DATA_RAW / "churn_raw.csv", index=False)
    (C.ROOT / "data" / "ground_truth").mkdir(parents=True, exist_ok=True)
    truth_clean.to_csv(C.ROOT / "data" / "ground_truth" / "clean_truth_for_audit_only.csv", index=False)
    truth["true_churn_rate"] = round(float(truth_clean[C.TARGET].mean()), 4)
    (C.REPORTS / "simulation_truth.json").write_text(json.dumps(truth, indent=2))
    print(f"   raw rows: {len(raw)}   ({time.time()-t:.1f}s)")

    t = step("2/6 Clean + quality checks")
    raw = pd.read_csv(C.DATA_RAW / "churn_raw.csv", dtype={"total_charges": object, C.TARGET: object})
    df, qrep = clean(raw)
    df.to_csv(C.DATA_PROCESSED / "churn_clean.csv", index=False)
    (C.REPORTS / "quality_report.json").write_text(json.dumps(qrep, indent=2))
    eda.missingness_plot(qrep["unusable_cells_before_cleaning"], qrep["missing_after_cleaning"])
    print(f"   {qrep['rows_in']} -> {qrep['rows_out']} rows   ({time.time()-t:.1f}s)")

    t = step("3/6 EDA with business questions")
    stats_df = eda.run_eda(df)
    stats_df.to_csv(C.REPORTS / "eda_stats.csv", index=False)
    (C.REPORTS / "key_numbers.json").write_text(json.dumps(eda.key_numbers(df), indent=2))
    print(f"   {len(stats_df)} feature tests   ({time.time()-t:.1f}s)")

    t = step("4/6 Segmentation")
    d, prof, zc, meta, (X, rename) = segment.fit_segments(df)
    segment.plot_segments(d, prof, zc, X, rename)
    prof.to_csv(C.REPORTS / "segment_profiles.csv", index=False)
    d[["customer_id", "segment"]].to_csv(C.DATA_PROCESSED / "customer_segments.csv", index=False)
    (C.REPORTS / "segmentation_meta.json").write_text(json.dumps(meta, indent=2))
    print(f"   k={meta['k']}  stability ARI={meta['stability_ARI_mean']}   ({time.time()-t:.1f}s)")

    t = step("5/6 Churn model (CV selection, held-out test, calibration, importance)")
    a = train_and_evaluate(df)
    plot_model(a)
    s = a["summary"]
    print(f"   chosen={s['chosen_model']}  test AUC={s['test'][s['chosen_model']]['roc_auc']:.3f}   ({time.time()-t:.1f}s)")

    t = step("6/6 Monitoring extension: drift + before/after")
    model = joblib.load(C.MODELS / "churn_model.joblib")["pipeline"]
    outs = {n: monitor.before_after_experiment(model, df, n) for n in monitor.DRIFT_SCENARIOS}
    pd.concat([o["report"].assign(scenario=n) for n, o in outs.items()]).to_csv(C.REPORTS / "drift_report.csv", index=False)
    (C.REPORTS / "before_after.json").write_text(json.dumps({n: o["result"] for n, o in outs.items()}, indent=2))
    monitor.plot_drift(outs)
    print(f"   done   ({time.time()-t:.1f}s)")

    report.build()
    print("\nAll outputs written to outputs/. Final report: outputs/final_report.md")


if __name__ == "__main__":
    main()
