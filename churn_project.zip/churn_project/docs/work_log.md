# Work Log (fill in as you work - the submission rules require a dated log)

> Template only: the entries below are the *planned* schedule from the brief. Replace "Actual" with what you really did and the date.

| Week | Planned (from brief) | Where it lives in this repo | Date done | Actual notes / blockers |
|---|---|---|---|---|
| 1 | Research, stakeholder framing, requirements, dataset, environment, initial design | `docs/requirements.md`, `src/config.py`, `src/generate_data.py` | | |
| 2 | Core implementation and analysis | `src/clean.py`, `src/eda.py`, `src/segment.py` | | |
| 3 | Testing/validation, refinement, mentor review | `src/model.py`, `tests/`, `docs/validation_evidence.md` | | |
| 4 | Final QA, documentation, presentation, submission | `outputs/final_report.md`, `README.md`, slides | | |
