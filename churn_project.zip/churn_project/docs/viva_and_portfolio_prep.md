# Viva Prep and Portfolio Material

Numbers are from the seeded run (`SEED=42`); if you change the seed, re-read `outputs/final_report.md`.

## Viva / interview answers (short versions)
1. **Business problem and success?** A subscription business loses ~28% of customers and can contact only 20%. Success = beat a simple rule on held-out
   data, calibrated probabilities, every segment tied to an action, reproducible in one command.
2. **Decision with the biggest impact?** Putting imputation *inside* the cross-validated pipeline and fixing the model-selection rule before touching
   the test set. It makes the 0.805 AUC an honest number. Close second: adding a rule-of-thumb baseline, which showed the model's edge is modest.
3. **How did you validate?** Cleaning counts checked against the simulator's ground truth; held-out test used once; bootstrap CIs; calibration by decile;
   segment stability (ARI 0.96); 25 automated tests.
4. **Edge cases and risks?** Duplicates, typos, text in numeric columns, impossible values, mixed labels, missing labels, unseen categories, missing
   columns. Risks: simulated data, associations not causes, fairness (age/region), placeholder business numbers.
5. **10x the data?** I have not load-tested it (this run used ~6,000 rows). Vectorised pandas/scikit-learn code usually copes with 10^5-10^6 rows on a laptop, so at 10x the first problems are likely storage and scheduling (warehouse table,
   scheduled job), then SQL/Spark for cleaning. The model itself (logistic regression) scales easily.
6. **Explain to a non-technical stakeholder?** "Customers on monthly contracts in their first months, with support problems or late payments, leave far
   more often. We rank customers by risk so the team calls the right 20%. Calling the model's top 20% reaches about 45 of every 100 leavers; picking at
   random reaches 18."
7. **Most independent problem-solving?** Monitoring: PSI raised identical alerts for harmless and harmful drift, so I added a scenario where the
   mechanism changes and showed retraining only helps then. Rule: alert -> check realised performance -> retrain if degraded.

## Likely follow-up questions
- *Why not accuracy?* 28% positives; accuracy rewards predicting "no churn". Budget constraint makes top-20% capture the real metric.
- *Why logistic regression over boosting?* CV AUC was higher (0.794 vs 0.782) and it is interpretable; the decision rule was set before testing.
- *Is the 0.8 AUC impressive?* It is limited by label noise built into the simulator; on real data expect different.
- *Does a discount cause lower churn?* Not shown. Association only; needs a randomised test.

## Resume bullet
**Customer Churn Investigation (Arrowstack Data Science Internship)** - Built an end-to-end churn analytics pipeline in Python (pandas, scikit-learn):
automated cleaning of a messy 6,100+ row export (8 defect types, verified against ground truth), six-segment customer segmentation (ARI 0.96),
and a calibrated churn model (held-out ROC-AUC 0.81 vs 0.74 for a rule-of-thumb) that reaches 45% of churners by contacting the top 20% of customers;
added PSI drift monitoring and a before/after retraining evaluation; 25 automated tests, one-command reproducibility.

## LinkedIn post draft
> Finished my Data Science internship project at Arrowstack: a customer churn investigation on a simulated subscription business.
>
> What I learned that tutorials skip:
> - Before building a model, I built a *rule-of-thumb baseline*. The model beat it, but only modestly, and I reported that honestly.
> - I corrupted my own data on purpose (duplicates, typos, impossible values) so I could test the cleaning code against ground truth.
> - Drift alerts don't tell you whether to retrain. In my experiment the same alerts fired when retraining was useless and when it was essential.
>
> Result: contacting the model's top 20% reaches ~45% of churners (18% at random), with calibrated probabilities and 25 automated tests.
> Code and report on GitHub: [link]
> #datascience #machinelearning #python #internship

## Presentation outline (8 slides)
1. Problem and stakeholder  2. Data and quality issues  3. Who churns (contract, tenure)  4. Segments and actions  5. Model vs baselines
6. Business case and its assumptions  7. Monitoring: before/after  8. Limitations and next steps
