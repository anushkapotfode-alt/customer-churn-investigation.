# Decision Log

| # | Decision | Alternatives considered | Why |
|---|---|---|---|
| D1 | Simulate data with a known mechanism and *then* corrupt it | Download a public churn dataset | Lets cleaning be tested against ground truth; no licensing/privacy risk; brief requires simulated data |
| D2 | Unknown categories and impossible values become **missing**, not silently kept or guessed | Clip to range; drop rows | Clipping invents data; dropping loses rows. Missing + imputation keeps the row and is counted |
| D3 | Deterministic cross-field repair only in cleaning (total = monthly x tenure) | Impute everything in cleaning | Statistical imputation fitted on all data would leak test information; it lives inside the CV pipeline |
| D4 | Duplicate ids: keep first | Keep last / most complete | No timestamp to say which is newer. Documented as a limitation |
| D5 | Rows with unreadable label dropped | Treat as "No" | Assuming "No" would bias churn downward |
| D6 | Segmentation on behaviour/commercial features, not on the label | Cluster including churn | Avoids circularity; churn rate by segment then validates the segments |
| D7 | k chosen by silhouette over 3-6 | Elbow; business-chosen k | Simple, reproducible. Silhouette is flat (0.19-0.20), so this is disclosed and stability (ARI) is reported |
| D8 | Model selection rule fixed before test: logistic unless boosting wins by > 0.01 CV AUC | Pick best on test | Prevents test-set peeking; prefers the interpretable model |
| D9 | Rule-of-thumb baseline (risk-flag count) in addition to random | Only compare to random | Random is too easy; a retention team would otherwise use a simple rule |
| D10 | Evaluate by top-20% capture, PR-AUC and calibration, not accuracy | Accuracy | 28% positive class makes accuracy misleading; budget constraint makes top-k the real metric |
| D11 | Business-case numbers are labelled illustrative and live in `config.py` | Hard-code in text | Finance can swap in real values; report regenerates |
| D12 | Monitor with PSI **and** realised performance on a drifted cohort | PSI only | Experiment showed PSI cannot tell harmless drift from harmful drift |
| D13 | Report text generated from saved results | Hand-written report | Numbers cannot drift from the analysis |
