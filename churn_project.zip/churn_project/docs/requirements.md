# Requirements and Acceptance Criteria

## Stakeholders
| Role | Needs |
|---|---|
| **Retention Manager** (primary) | Ranked list of who to contact, reasons, and a recommended action per segment |
| **Finance Analyst** (secondary) | Revenue at risk, campaign cost vs retained margin, credible assumptions |
| **Data/Platform owner** | Reproducible pipeline, drift monitoring, no unexplained data changes |

## Decision enabled
Each campaign cycle the retention team can contact **20%** of customers. The output tells them *which* 20% and *what to offer*.

## Inputs / outputs
- **Input:** customer-level export (CSV) with the columns in `data_dictionary.md`.
- **Outputs:** cleaned data + quality report; EDA findings; segment profiles; churn probability and risk band per customer; final report.

## Success metrics (fixed before analysis)
1. Every data-quality issue is detected, counted and handled (verified against the simulator's ground truth).
2. Model ROC-AUC on held-out data beats the rule-of-thumb baseline, with a confidence interval.
3. Predicted probabilities are calibrated (mean decile gap < 5 percentage points; Brier below base-rate Brier).
4. Each segment maps to a concrete retention action.
5. One-command reproducibility; tests pass.

## Scope
**In:** churn drivers, segmentation, risk ranking, monitoring extension. **Out:** causal/uplift estimation, real-time serving,
time-to-event modelling, real customer data.

## Functional requirements
| ID | Requirement | Evidence |
|---|---|---|
| F1 | Data dictionary | `docs/data_dictionary.md` |
| F2 | Cleaning + quality checks with counts | `outputs/reports/quality_report.json`, `tests/test_clean.py` |
| F3 | EDA organised by business question | `outputs/figures/01-08`, `outputs/reports/eda_stats.csv` |
| F4 | Evidence-based insights | `outputs/final_report.md` sections 4-6 |
| F5 | Limitations and next steps | `docs/limitations_and_roadmap.md`, report sections 8-9 |
| F6 | Edge cases: duplicates, typos, text in numbers, impossible values, missing label, unseen categories, missing columns | `tests/` |
| F7 | Validation step with retained evidence | `docs/validation_evidence.md` |

## Edge cases handled
Exact and conflicting duplicate ids; inconsistent spellings/whitespace; numbers exported as text (`" "`, `"N/A"`); impossible ages,
negative tenure, x100 charges; mixed label formats (`Yes/yes/Y/1`); missing labels (dropped, counted); unseen category at scoring time
(encoded as unknown); missing values at scoring time (imputed with training medians + missing indicators); missing required columns
(clear error, exit code 2).
