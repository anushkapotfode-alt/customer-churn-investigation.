# Data Dictionary

Simulated subscription customers, one row per customer. "Valid range" values outside the range become missing during cleaning.

| Column | Type | Meaning | Valid values / range | Cleaning rule |
|---|---|---|---|---|
| `customer_id` | text | Unique customer id | unique | Duplicate ids: keep first, count the rest |
| `plan` | category | Subscription tier | Basic, Standard, Premium | Trim, case-fold, map to canonical; unknown -> missing |
| `contract` | category | Commitment length | Month-to-month, One year, Two year | Same; "month to month", "MONTH-TO-MONTH" etc. accepted |
| `payment_method` | category | How the customer pays | Card, UPI, Bank Transfer, Wallet | Same |
| `region` | category | Sales region | North, South, East, West | Same |
| `age` | number | Age in years | 18-100 | Out of range -> missing; imputed in model pipeline |
| `tenure_months` | number | Months as a customer | 0-120 | Negative -> missing, then repaired as total / monthly when possible |
| `monthly_charges` | number | Current monthly bill | 5-300 | Out of range or missing -> repaired as total / tenure when possible |
| `total_charges` | number | Lifetime billed amount (exported as text) | 0-40,000 | Text/blank -> numeric; missing -> monthly x tenure |
| `support_tickets_90d` | count | Support tickets in last 90 days | 0-50 | Out of range -> missing |
| `logins_30d` | count | Logins in last 30 days | 0-300 | Negative -> missing |
| `avg_session_min` | number | Average session length (minutes) | 0-300 | Out of range -> missing |
| `late_payments_6m` | count | Late payments in last 6 months | 0-6 | Out of range -> missing |
| `autopay` | flag 0/1 | Automatic payment enabled | 0, 1 | Else missing |
| `price_increase_recent` | flag 0/1 | Experienced a price increase recently | 0, 1 | Else missing |
| `discount_flag` | flag 0/1 | Currently on a discount | 0, 1 | Else missing |
| `referred` | flag 0/1 | Joined via referral | 0, 1 | Else missing |
| `churned` | flag 0/1 (target) | Left the service | Yes/No/Y/N/1/0 accepted | Mapped to 0/1; unreadable -> row dropped |

**Not used as model inputs:** `customer_id`, `churned` (guarded by an assertion in `src/model.py`).
**Leakage note:** all features are measured before the churn outcome; `total_charges` is correlated with tenure but is not derived from the label.
**Sensitive attributes:** `age` and `region` - review for fairness before real use.
