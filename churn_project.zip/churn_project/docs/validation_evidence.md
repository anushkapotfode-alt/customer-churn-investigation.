# Validation Evidence (maps acceptance criteria to proof)

Run `python run_pipeline.py && python -m pytest -q` to regenerate every item below.

| Acceptance criterion | Evidence | Where |
|---|---|---|
| Core requirements complete and mapped | Requirements table F1-F7 | `docs/requirements.md` |
| Reproducible by a mentor | Seeded; 2 runs give identical model AUC (test); one command | `tests/test_model.py::test_training_is_reproducible`, README |
| Cleaning is correct | Detection counts match simulator ground truth; labels equal truth; no out-of-range value survives; duplicates removed | `tests/test_clean.py` (10 tests) |
| No data leakage | Target/id excluded from features (assertion + test); preprocessing inside the pipeline; test set used once after model selection | `src/model.py`, `tests/test_model.py` |
| Model is better than baselines | Held-out ROC-AUC 0.805 vs rule 0.738 vs random 0.521; bootstrap 95% CI for AUC and for the capture gain (+1.0 to +10.6 pp) | `outputs/reports/model_metrics.json` |
| Probabilities are calibrated | Mean decile gap 1.8 pp; Brier 0.152 vs 0.200 base-rate | `outputs/reports/calibration_table.csv`, `tests/test_model.py` |
| Segments are stable | ARI 0.96 mean / 0.95 min over 5 resamples | `outputs/reports/segmentation_meta.json` |
| Robust to bad input | Unseen category, missing values, missing required column, label-free scoring file | `tests/test_model.py`, `tests/test_monitor_and_score.py` |
| Monitoring works | PSI near 0 for same distribution, > 0.25 for shifted; 2 drift scenarios evaluated before vs after | `tests/test_monitor_and_score.py`, `outputs/reports/before_after.json` |
| Known issues disclosed | Limitations section | `outputs/final_report.md` section 8 |

## Test run
`pytest -q` -> **25 passed**.

## Known issues found during development (kept for honesty)
1. First draft of the duplicate-removal test assumed exact vs conflicting duplicates split cleanly. A conflicting copy whose charge was already
   missing is identical to an exact copy (NaN x 1.1 = NaN), so the test now checks the total removed. The cleaner was behaving correctly.
2. First draft of the report matched segment actions on the word "tickets" and wrongly gave service-recovery actions to *low*-ticket segments.
   Matching is now direction-aware.
3. The model improves on the rule-of-thumb only modestly in business value (see report section 1). This is reported, not hidden.
