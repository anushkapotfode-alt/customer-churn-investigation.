# Limitations and Production-Readiness Roadmap

## Limitations
- Simulated data: results show the method works, not that these effects hold in a real business.
- Associations, not causal effects; "who will churn" is not "who can be saved".
- Business case uses placeholder assumptions (offer cost, save rate, margin, value horizon).
- Binary outcome only; no time-to-event view.
- Weakly separated segments (silhouette ~0.20); names are auto-generated from strongest features.
- Duplicate ids resolved by "keep first".
- Age and region are inputs; fairness not yet assessed.

## Roadmap
| Area | Step | Why |
|---|---|---|
| **Security & privacy** | Remove direct identifiers before analysis; role-based access to scored lists; encrypt data at rest; log access to risk lists | Churn lists are commercially sensitive and may be personal data |
| **Governance** | Fairness review across age/region; model card (purpose, data, metrics, limits); documented approval before use in decisions | Avoid unequal treatment; auditability |
| **Scalability** | Move CSV to a warehouse table; schedule `run_pipeline.py` (cron/Airflow); score in batches; swap pandas for SQL/Spark only if volume demands | Not load-tested (6,000 rows so far). Test at 10^5-10^6 rows; expect storage and scheduling, not new algorithms, to be the first constraint |
| **Maintainability** | CI to run `pytest` on every change; pin dependency versions; schema validation with a contract test against the source system | Catch silent upstream changes |
| **Monitoring** | Weekly PSI job (built); add realised-performance check once labels arrive (lag-aware); alert on calibration drift; retrain only when performance degrades | Experiment showed PSI alone cannot decide retraining |
| **Impact measurement** | Randomised holdout in the first campaigns; move to uplift modelling | Needed to claim retention is *caused* by the campaign |
| **Explainability** | Per-customer reason codes from logistic contributions in the risk list | Retention agents need to know what to say |
