# Customer Churn Investigation - Final Report

*Arrowstack Data Science internship, Project 1. All data is simulated; no real customers are involved.*

## 1. Executive summary

- **Problem.** A subscription business loses **27.7%** of customers. The retention team can contact only
  **20%** of the base, so the question is *who* to contact and *what* to offer.
- **Who churns.** Month-to-month contracts churn at **39.7%** versus
  **7.3%** on two-year contracts. They are 56% of customers
  but **80%** of monthly revenue lost. Customers in their first 6 months churn at
  40.1% (versus 11.4% after 24 months).
- **Why (associations).** Short tenure, low logins, 3+ support tickets, late payments, no autopay and a recent price increase
  all go with higher churn. These are associations in simulated data, not proven causes.
- **Segments.** Six behavioural segments with churn from 5.1% to 41.5%,
  stable under resampling (ARI 0.96).
- **Model.** Logistic regression reaches ROC-AUC **0.805** on a held-out test set
  (95% CI 0.777-0.832); contacting the top 20% by risk reaches
  **45%** of churners versus 18% at random and
  39% for a simple rule-of-thumb.
- **Honest caveat.** The rule-of-thumb already captures most of the value. Under the illustrative assumptions below the model adds
  186 net value over it on a 1197-customer test set; the gain in
  churners reached has a 95% CI of +1.0 to +10.6 percentage points.

## 2. Stakeholder, decision and success criteria (defined before analysis)

- **Primary stakeholder:** Retention Manager. **Secondary:** Finance Analyst (revenue at risk, campaign ROI).
- **Decision enabled:** which customers to contact in each campaign cycle, and which action to take per segment.
- **Success criteria:** (1) data issues documented and handled; (2) model beats a rule-of-thumb baseline on held-out data;
  (3) probabilities are calibrated well enough to rank *and* to estimate revenue at risk; (4) every insight maps to a retention action;
  (5) the work is reproducible with one command.

## 3. Data and quality

Raw export: **6,138** rows. After cleaning: **5,985** customers.

| Check | Result |
|---|---|
| Exact duplicate rows removed | 120 |
| Conflicting duplicate customer ids removed (kept first) | 18 |
| Category spellings standardised (case/whitespace/hyphens) | 1334 |
| Text in numeric columns set to missing | 64 |
| Out-of-range values set to missing | 77 |
| Cross-field repairs (total = monthly x tenure) | 213 |
| Rows dropped for missing/unreadable label | 15 |
| Remaining missing values (imputed inside the model pipeline) | 532 cells, max 3.4% in any column |

The simulator recorded exactly what it corrupted (120 exact duplicates, 18 conflicting
duplicates, 15 missing labels), so detection counts can be audited against ground truth (see `tests/`).
See `docs/data_dictionary.md` for every column.

![data quality](figures/00_data_quality.png)

## 4. Business questions and findings

- **Q1.** Who churns most - which contract, plan and payment groups?
- **Q2.** How early in the lifecycle do customers leave?
- **Q3.** Does service friction (support tickets, late payments) relate to churn?
- **Q4.** Does product engagement (logins) separate churners from stayers?
- **Q5.** Do price increases, discounts, autopay and referrals matter?
- **Q6.** How much monthly revenue is lost to churn, and where is it concentrated?

**Q1 Who churns most.** Contract is the strongest group difference (39.7% /
16.7% / 7.3% for month-to-month / one-year / two-year).
Basic plan churns 31.1% versus 23.7% for Premium.
![who churns](figures/01_who_churns.png)

**Q2 Lifecycle.** Early life is the danger zone: 40.1% churn in the first 6 months.
![tenure](figures/03_tenure.png)

**Q3 Service friction.** 3+ tickets in 90 days: 41.8% churn (vs 24.3% for 0-1).
2+ late payments: 39.1% (vs 23.7% for none).
![friction](figures/04_service_friction.png)

**Q4 Engagement.** Median logins: 12 for churners vs 14 for stayers.
![engagement](figures/05_engagement.png)

**Q5 Price, autopay and incentives.** Recent price increase: 36.3% vs 25.5%.
Autopay: 23.1% vs 32.9% without it.
![price and autopay](figures/06_price_autopay.png)

**Q6 Revenue.** Churned customers represented **71,898** in monthly charges.
![revenue lost](figures/07_revenue_lost.png)

**Strength of evidence.** With ~6,000 rows nearly every feature is statistically significant, so effect sizes are the useful ranking:

| feature | Effect size type | Effect | p (Bonferroni) |
|---|---|---|---|
| tenure_months | Cliff's delta (churn>stay) | -0.341 | <0.001 |
| total_charges | Cliff's delta (churn>stay) | -0.329 | <0.001 |
| contract | Cramer's V | 0.309 | <0.001 |
| logins_30d | Cliff's delta (churn>stay) | -0.21 | <0.001 |
| support_tickets_90d | Cliff's delta (churn>stay) | 0.173 | <0.001 |
| avg_session_min | Cliff's delta (churn>stay) | -0.17 | <0.001 |
| late_payments_6m | Cliff's delta (churn>stay) | 0.131 | <0.001 |
| autopay | Cramer's V | 0.109 | <0.001 |

## 5. Customer segments

KMeans (k=6, chosen by silhouette over k=3-6) on tenure, spend, logins, session length, tickets and late payments.
The label is *not* used for clustering. Silhouette is low and flat across k (3: 0.19, 4: 0.20, 5: 0.20, 6: 0.20),
meaning these are practical operating groups rather than sharply separated natural clusters; they are, however, reproducible
(ARI 0.96 mean, 0.95 minimum over five 80% subsamples).

| Segment | Customers | Churn rate | Avg tenure (mo) | Avg monthly charge | Share of revenue lost | Profile | Suggested retention action |
|---|---|---|---|---|---|---|---|
| S1 | 721 | 41.5% | 16.6 | 43.5 | 18% | high tickets + low logins | Service recovery: proactive outreach after the 2nd ticket, named support owner, fix root causes. |
| S2 | 555 | 41.3% | 18.5 | 44.2 | 13% | high late payments + low tenure | Billing fixes: autopay nudges, flexible due dates, reminder cadence before the due date. |
| S3 | 1489 | 36.7% | 12.7 | 36.6 | 27% | low session length + low logins | Re-engagement: onboarding/usage nudges and feature education in the first weeks. |
| S4 | 1522 | 22.3% | 14.4 | 34.6 | 16% | high session length + high logins | Lock-in: offer annual/two-year contract incentives while engagement is high. |
| S5 | 920 | 22.1% | 15.6 | 82.0 | 23% | high spend + low tickets | Protect high-value accounts: account-manager check-ins and plan-fit reviews before renewal. |
| S6 | 778 | 5.1% | 61.3 | 43.8 | 2% | high tenure + low tickets | Loyalty protection: low-touch recognition; do not spend discount budget here. |

![segments](figures/09_segments.png)

## 6. Churn prediction

**Method.** 80/20 stratified split. Imputation, scaling and one-hot encoding live inside the pipeline, so they are fitted on training folds only.
Model choice used 5-fold CV on the training set with a rule fixed in advance: take logistic regression unless gradient boosting is better
by more than 0.01 CV ROC-AUC (CV: logistic 0.794, boosting 0.782).
The test set was used once, afterwards.

| Approach | ROC-AUC | PR-AUC | Top-20% precision | Top-20% churners reached | Lift |
|---|---|---|---|---|---|
| Random targeting | 0.521 | 0.290 | 25.4% | 18.4% | 0.92x |
| Rule-of-thumb (risk-flag count) | 0.738 | 0.526 | 54.2% | 39.2% | 1.95x |
| Logistic regression (chosen) | 0.805 | 0.612 | 62.1% | 44.9% | 2.24x |
| Gradient boosting | 0.791 | 0.590 | 60.8% | 44.0% | 2.19x |

Test set: 1197 customers, churn rate 27.7%. Brier score 0.152
(always predicting the base rate: 0.200). Average gap between predicted and observed churn across
deciles: 1.8 percentage points.

**Most important inputs (permutation importance):** contract, tenure_months, logins_30d, support_tickets_90d.
![model](figures/10_model_evaluation.png)
![logistic effects](figures/11_logistic_effects.png)

### Retention business case (illustrative assumptions)

Contact the top 20% by risk, evaluated on the 1197-customer test set. Assumptions (edit `src/config.py`; replace with finance-approved numbers):
offer cost 5 per customer, 30% of contacted would-be churners are retained,
gross margin 60%, retained customers pay 12 more months.

| Targeting | Customers contacted | Expected saved | Margin retained | Cost | Net value |
|---|---|---|---|---|---|
| Random | 240 | 18 | 5,594 | 1,200 | 4,394 |
| Rule-of-thumb | 240 | 39 | 12,922 | 1,200 | 11,722 |
| Model | 240 | 45 | 13,108 | 1,200 | 11,908 |

## 7. Extension: monitoring and before/after evaluation

**Monitor.** Population Stability Index (PSI) per feature and on the model score; amber at 0.1, red at 0.25.
Two simulated "next-quarter" cohorts of 3,000 customers were scored:

- **A. Customers change, mechanism unchanged** (lower engagement, more price increases).
- **B. The churn mechanism itself changes** (price increases hurt much more; contract lock-in protects less).

| Scenario | Model | ROC-AUC | Top-20% recall |
|---|---|---|---|
| A: customers change, mechanism same | Original (before) | 0.802 | 42.0% |
| A: customers change, mechanism same | Retrained (after) | 0.794 | 40.1% |
| B: churn mechanism changes | Original (before) | 0.738 | 33.8% |
| B: churn mechanism changes | Retrained (after) | 0.793 | 38.7% |

What this shows:

1. PSI raised the **same alerts in both scenarios** (price_increase_recent, logins_30d). Input drift tells you *that something changed*, not whether
   the model got worse.
2. In scenario A the original model did about as well as a retrained one (ROC-AUC 0.802 vs 0.794), so retraining would not have paid off.
3. In scenario B performance dropped and retraining recovered it (ROC-AUC 0.738 -> 0.793).
4. Therefore the monitoring rule is: *drift alert -> check realised performance on newly labelled customers -> retrain only if it degrades.*
   Labels arrive with a lag, so a lag-aware performance check is part of the roadmap.

Top input-drift rows, scenario A:

| feature | psi | status |
|---|---|---|
| price_increase_recent | 0.2707 | ALERT |
| logins_30d | 0.2688 | ALERT |
| avg_session_min | 0.2168 | WARN |
| support_tickets_90d | 0.1451 | WARN |
| MODEL SCORE | 0.1375 | WARN |

![drift](figures/12_drift_monitoring.png)

**Automation.** `python run_pipeline.py` regenerates every table, figure, model and this report in about 10 seconds on the
development machine (measured). Compare that with your own estimate of the manual notebook process to quantify the productivity gain
for your write-up. `python -m src.score` produces a ranked risk list from a new customer file, with schema validation and
unseen-category handling.

## 8. Limitations

- **Simulated data.** Effects are as realistic as the simulator, not as realistic as a real business. The model recovers the simulator's
  mechanism; results on real data would differ and need re-validation.
- **Associations, not causes.** A discount flag with lower churn does not prove discounts cause retention (customers who were offered discounts may differ).
- **Business-case numbers are assumptions.** Save rate, cost and margin are placeholders; net value scales directly with them.
- **No lifetime view.** Churn here is a single binary outcome; there is no time-to-event modelling, so "when" is only approximated by tenure.
- **Segments are weakly separated** (low silhouette) and named automatically from their strongest features.
- **Duplicate handling keeps the first record** for conflicting ids; in real data the source of truth should decide.
- **Fairness.** Age and region are inputs. Before real use, check outcomes across groups and consider removing sensitive attributes.

## 9. Recommendations and next steps

1. Pilot the model-ranked list on the top 20% with a **randomised holdout** so uplift (not just churn risk) is measured.
2. Use the segment actions in section 5; start with the highest churn / highest revenue-at-risk segments.
3. Add an early-life programme (first 90 days) and a price-increase communication plan.
4. Move from "who will churn" to "who can be saved" (uplift modelling) once pilot data exist.
5. Productionise per `docs/limitations_and_roadmap.md` (security, scalability, governance, maintainability).
