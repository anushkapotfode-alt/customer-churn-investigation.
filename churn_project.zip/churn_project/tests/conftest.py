import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import generate_data as G  # noqa: E402


@pytest.fixture(scope="session")
def sim():
    """A small clean table, its corrupted raw version and the ground-truth corruption counts."""
    clean_truth = G.simulate(n=2500, seed=11)
    raw, truth = G.make_raw(clean_truth, seed=11)
    return clean_truth, raw, truth
