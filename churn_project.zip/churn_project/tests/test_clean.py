import numpy as np
import pandas as pd
import pytest

from src import config as C
from src.clean import SchemaError, clean, standardise_category, validate_schema


def test_exact_and_conflicting_duplicates_removed(sim):
    clean_truth, raw, truth = sim
    df, rep = clean(raw)
    assert df[C.ID_COL].is_unique
    # A "conflicting" copy whose monthly_charges was already NaN is indistinguishable from an exact copy
    # (NaN * 1.1 = NaN), so the split between the two counters can shift by a row or two. The invariant
    # is the total: every injected duplicate row is removed, and nothing else.
    removed = rep["exact_duplicates_removed"] + rep["conflicting_id_duplicates_removed"]
    assert removed == truth["exact_duplicates"] + truth["conflicting_id_duplicates"]
    assert abs(rep["exact_duplicates_removed"] - truth["exact_duplicates"]) <= 3


def test_rows_out_equals_true_rows_minus_missing_labels(sim):
    clean_truth, raw, truth = sim
    df, rep = clean(raw)
    assert len(df) == truth["rows_true"] - truth["label_missing"]
    assert rep["label_unmapped_or_missing_rows_dropped"] == truth["label_missing"]


def test_labels_are_binary_ints_and_match_truth(sim):
    clean_truth, raw, _ = sim
    df, _ = clean(raw)
    assert set(df[C.TARGET].unique()) <= {0, 1}
    merged = df.merge(clean_truth[[C.ID_COL, C.TARGET]], on=C.ID_COL, suffixes=("", "_true"))
    assert (merged[C.TARGET] == merged[C.TARGET + "_true"]).all()


def test_categories_are_canonical_after_cleaning(sim):
    _, raw, _ = sim
    df, _ = clean(raw)
    for col, canon in C.CATEGORICAL.items():
        assert set(df[col].dropna().unique()) <= set(canon)


def test_no_value_outside_valid_range_survives(sim):
    _, raw, _ = sim
    df, _ = clean(raw)
    for col, (lo, hi) in C.NUMERIC_BOUNDS.items():
        assert df[col].dropna().between(lo, hi).all(), col


def test_cross_field_repair_recovers_monthly_charge(sim):
    clean_truth, raw, _ = sim
    df, rep = clean(raw)
    assert rep["cross_field_repairs"]["monthly_charges_from_total_and_tenure"] > 0
    m = df.merge(clean_truth[[C.ID_COL, "monthly_charges"]], on=C.ID_COL, suffixes=("", "_true"))
    ok = m["monthly_charges"].notna()
    rel_err = ((m.loc[ok, "monthly_charges"] - m.loc[ok, "monthly_charges_true"]).abs()
               / m.loc[ok, "monthly_charges_true"])
    assert rel_err.quantile(0.99) < 0.12      # total has +-5% noise, so repairs are approximate by design


def test_unknown_category_becomes_missing_not_silently_kept():
    s = pd.Series(["Basic", "basic ", "Platinum", np.nan])
    out, changed, unknown = standardise_category(s, C.PLANS)
    assert out.tolist()[:2] == ["Basic", "Basic"]
    assert pd.isna(out.iloc[2]) and unknown == 1 and changed == 1


def test_missing_required_column_raises_clear_error(sim):
    _, raw, _ = sim
    with pytest.raises(SchemaError, match="tenure_months"):
        validate_schema(raw.drop(columns=["tenure_months"]))


def test_label_not_required_for_scoring(sim):
    _, raw, _ = sim
    df, _ = clean(raw.drop(columns=[C.TARGET]), require_label=False)
    assert C.TARGET not in df.columns and len(df) > 0


def test_cleaning_is_idempotent_on_clean_input(sim):
    clean_truth, _, _ = sim
    df, rep = clean(clean_truth)
    assert rep["exact_duplicates_removed"] == 0
    assert sum(rep["out_of_range_set_missing"].values()) == 0
    assert len(df) == len(clean_truth)
