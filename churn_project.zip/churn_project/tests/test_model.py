import numpy as np
import pandas as pd
import pytest

from src import config as C
from src import generate_data as G
from src.clean import clean
from src.model import rule_score, split, topk_stats, train_and_evaluate


@pytest.fixture(scope="module")
def trained(sim):
    _, raw, _ = sim
    df, _ = clean(raw)
    return df, train_and_evaluate(df, save=False)


def test_target_and_id_are_not_model_inputs():
    assert C.TARGET not in C.FEATURES and C.ID_COL not in C.FEATURES


def test_split_is_stratified_and_disjoint(trained):
    df, _ = trained
    X_tr, X_te, y_tr, y_te = split(df)
    assert set(X_tr.index).isdisjoint(X_te.index)
    assert abs(y_tr.mean() - y_te.mean()) < 0.01


def test_model_beats_random_and_rule_baseline_on_test(trained):
    _, a = trained
    t = a["summary"]["test"]
    ch = a["summary"]["chosen_model"]
    assert t[ch]["roc_auc"] > 0.70
    assert t[ch]["roc_auc"] > t["random"]["roc_auc"] + 0.15
    assert t[ch]["roc_auc"] >= t["rule_baseline"]["roc_auc"]


def test_probabilities_are_valid_and_reasonably_calibrated(trained):
    _, a = trained
    p = a["scored_test"]["churn_probability"]
    assert p.between(0, 1).all()
    assert a["summary"]["calibration_mean_abs_gap"] < 0.05
    assert a["summary"]["brier_score"] < a["summary"]["brier_baseline_prevalence"]


def test_model_handles_unseen_category_and_missing_values(trained):
    df, a = trained
    row = df[C.FEATURES].head(5).copy()
    row.loc[row.index[0], "plan"] = "Platinum"            # never seen in training
    row.loc[row.index[1], "age"] = np.nan
    row.loc[row.index[2], ["logins_30d", "avg_session_min"]] = np.nan
    p = a["model"].predict_proba(row)[:, 1]
    assert np.isfinite(p).all() and ((0 <= p) & (p <= 1)).all()


def test_topk_stats_hand_checkable():
    y = np.array([1, 0, 1, 0, 0, 0, 0, 0, 0, 0])
    s = np.array([.9, .8, .7, .1, .1, .1, .1, .1, .1, .1])
    r = topk_stats(y, s, 0.3)               # top 3 = idx 0,1,2 -> 2 churners
    assert r["contacted"] == 3 and r["churners_captured"] == 2
    assert r["recall"] == 1.0 and abs(r["precision"] - 2 / 3) < 1e-9 and abs(r["lift"] - (2 / 3) / 0.2) < 1e-9


def test_rule_score_is_deterministic_given_seed(trained):
    df, _ = trained
    X = df[C.FEATURES].head(50)
    assert np.array_equal(rule_score(X, 1), rule_score(X, 1))


def test_training_is_reproducible(sim):
    _, raw, _ = sim
    df, _ = clean(raw)
    a1 = train_and_evaluate(df, save=False)["summary"]["test"]
    a2 = train_and_evaluate(df, save=False)["summary"]["test"]
    ch = "logistic" if "logistic" in a1 else "gradient_boosting"
    assert a1[ch]["roc_auc"] == a2[ch]["roc_auc"]
