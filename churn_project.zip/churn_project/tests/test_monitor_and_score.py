import joblib
import numpy as np
import pandas as pd
import pytest

from src import config as C
from src import generate_data as G
from src.clean import clean
from src.model import train_and_evaluate
from src.monitor import psi_categorical, psi_numeric, status
from src.score import main as score_main, score_dataframe


def test_psi_is_near_zero_for_same_distribution():
    rng = np.random.default_rng(0)
    a, b = pd.Series(rng.normal(0, 1, 5000)), pd.Series(rng.normal(0, 1, 5000))
    assert psi_numeric(a, b) < 0.05


def test_psi_flags_a_big_shift():
    rng = np.random.default_rng(0)
    a, b = pd.Series(rng.normal(0, 1, 5000)), pd.Series(rng.normal(1.0, 1, 5000))
    assert psi_numeric(a, b) > C.PSI_ALERT and status(psi_numeric(a, b)) == "ALERT"


def test_psi_categorical_detects_mix_change():
    a = pd.Series(["x"] * 800 + ["y"] * 200)
    b = pd.Series(["x"] * 400 + ["y"] * 600)
    assert psi_categorical(a, b) > C.PSI_ALERT
    assert psi_categorical(a, a) == pytest.approx(0, abs=1e-9)


@pytest.fixture(scope="module")
def bundle(sim, tmp_path_factory):
    _, raw, _ = sim
    df, _ = clean(raw)
    a = train_and_evaluate(df, save=False)
    meta = {"risk_bands": a["summary"]["risk_bands"], "chosen_model": a["summary"]["chosen_model"]}
    return {"pipeline": a["model"], "meta": meta}


def test_score_output_is_ranked_with_bands_and_no_label_needed(sim, bundle):
    _, raw, _ = sim
    out = score_dataframe(raw.drop(columns=[C.TARGET]).head(300), bundle)
    assert out["churn_probability"].is_monotonic_decreasing
    assert set(out["risk_band"]) <= {"High", "Medium", "Low"}
    assert out[C.ID_COL].is_unique


def test_cli_returns_error_code_on_missing_column(sim, bundle, tmp_path):
    _, raw, _ = sim
    model_path = tmp_path / "m.joblib"
    joblib.dump(bundle, model_path)
    bad = tmp_path / "bad.csv"
    raw.drop(columns=["contract"]).head(20).to_csv(bad, index=False)
    code = score_main(["--input", str(bad), "--output", str(tmp_path / "o.csv"), "--model", str(model_path)])
    assert code == 2


def test_cli_happy_path(sim, bundle, tmp_path):
    _, raw, _ = sim
    model_path = tmp_path / "m.joblib"
    joblib.dump(bundle, model_path)
    good = tmp_path / "good.csv"
    raw.drop(columns=[C.TARGET]).head(50).to_csv(good, index=False)
    out = tmp_path / "o.csv"
    assert score_main(["--input", str(good), "--output", str(out), "--model", str(model_path)]) == 0
    assert len(pd.read_csv(out)) > 0


def test_simulator_is_deterministic():
    a, b = G.simulate(n=500, seed=3), G.simulate(n=500, seed=3)
    pd.testing.assert_frame_equal(a, b)
    assert not a.equals(G.simulate(n=500, seed=4))
